namespace Proyecto_Dnd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Menu();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Menu()
        {
            this.BackgroundImage = Image.FromFile("dragon.png");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            this.Text = "Dungeons && Dragons";
            int margenDerecho = 20;
            Label titulo = new Label();
            titulo.Text = "Dungeons && Dragons";
            titulo.Font = new Font("Papyrus", 28, FontStyle.Bold);
            titulo.ForeColor = Color.DarkRed;
            titulo.BackColor = Color.Transparent;
            titulo.AutoSize = true;
            titulo.Top = 10;
            titulo.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            this.Controls.Add(titulo);
            titulo.Left = this.ClientSize.Width - titulo.Width - margenDerecho;

            Button PartidaN = new Button();
            PartidaN.Text = "Nueva partida";
            PartidaN.Font = new Font("Papyrus", 11, FontStyle.Bold);
            PartidaN.Size = new Size(300, 40);
            PartidaN.BackColor = Color.Black;
            PartidaN.ForeColor = Color.Orange;
            PartidaN.FlatStyle = FlatStyle.Flat;
            PartidaN.Top = 120;
            PartidaN.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            this.Controls.Add(PartidaN);
            PartidaN.Left = this.ClientSize.Width - PartidaN.Width - margenDerecho;

            Button ContinuaP = new Button();
            ContinuaP.Text = "Continuar";
            ContinuaP.Font = new Font("Papyrus", 11, FontStyle.Bold);
            ContinuaP.Size = new Size(300, 40);
            ContinuaP.BackColor = Color.Black;
            ContinuaP.ForeColor = Color.Orange;
            ContinuaP.Top = 170;
            ContinuaP.FlatStyle = FlatStyle.Flat;
            ContinuaP.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            this.Controls.Add(ContinuaP);
            ContinuaP.Left = this.ClientSize.Width - ContinuaP.Width - margenDerecho;

            Button Salir = new Button();
            Salir.Text = "Salir";
            Salir.Font = new Font("Papyrus", 11, FontStyle.Bold);
            Salir.Size = new Size(300, 40);
            Salir.BackColor = Color.Black;
            Salir.ForeColor = Color.Orange;
            Salir.Top = 220;
            Salir.FlatStyle = FlatStyle.Flat;
            Salir.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            this.Controls.Add(Salir);
            Salir.Left = this.ClientSize.Width - Salir.Width - margenDerecho;

            PartidaN.Click += PartidaN_Click;
            ContinuaP.Click += ContinuaP_Click;
            Salir.Click += Salir_Click;

        }
        private void PartidaN_Click(object sender, EventArgs e)
        {
            Form2 seleccionClase = new Form2();
            seleccionClase.Show();
            this.Hide(); 

        }

        private void ContinuaP_Click(object sender, EventArgs e)
        {
            Form9 login = new Form9();
            login.Show();
            this.Hide();
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }

}
