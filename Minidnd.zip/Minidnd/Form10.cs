﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace Proyecto_Dnd
{
    public partial class Form10 : Form
    {
        private int jugadorId;
        private PersonajeCompleto pj;
        private ListView listaItems;
        private Panel panelEquipo;
        private Label lblArmaEquipada, lblArmaduraEquipada, lblAccesorioEquipado;
        private Label lblEstadisticas, lblOro;
        private Button btnEquipar, btnUsar, btnDesequipar, btnCerrar;

        // Constructor mejorado que recibe el ID del jugador
        public Form10(int idJugador)
        {
            jugadorId = idJugador;
            InitializeComponent();
            ConfigurarUI();
            CargarPersonajeCompleto(); // Carga todo en una sola llamada
            CargarDatosUI();
        }

        // Constructor alternativo (retrocompatibilidad)
        // IMPORTANTE: Verifica que Form9.JugadorIdActual esté correctamente establecido
        public Form10(PersonajeCompleto personaje)
        {
            // Intentar obtener el ID desde Form9, si falla usar consulta por nombre
            jugadorId = Form9.JugadorIdActual;

            // Validación de seguridad
            if (jugadorId <= 0 && personaje != null && !string.IsNullOrEmpty(personaje.Nombre))
            {
                // Buscar el ID por nombre como fallback
                jugadorId = ObtenerIdPorNombre(personaje.Nombre);
            }

            InitializeComponent();
            ConfigurarUI();
            CargarPersonajeCompleto();
            CargarDatosUI();
        }

        // Método auxiliar para obtener ID por nombre de personaje
        private int ObtenerIdPorNombre(string nombrePersonaje)
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    string query = "SELECT ID_Jugador FROM jugador WHERE Nombre = @nombre LIMIT 1";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@nombre", nombrePersonaje);
                        object result = cmd.ExecuteScalar();
                        return result != null ? Convert.ToInt32(result) : 0;
                    }
                }
            }
            catch
            {
                return 0;
            }
        }

        // Método unificado que carga todo el personaje desde la BD
        private void CargarPersonajeCompleto()
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    // 1. Cargar datos básicos del personaje
                    string queryPersonaje = @"
                        SELECT j.ID_Jugador, j.Nombre, j.HP, j.Fuerza, j.Destreza,
                               j.Constitucion, j.Inteligencia, j.Sabiduria, j.Carisma,
                               j.ID_Nivel, j.Oro,
                               COALESCE(c.Nombre, 'Sin clase') AS NombreClase
                        FROM jugador j
                        LEFT JOIN clase c ON j.ID_Clase = c.ID_Clase
                        WHERE j.ID_Jugador = @id";

                    using (MySqlCommand cmd = new MySqlCommand(queryPersonaje, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                pj = new PersonajeCompleto
                                {
                                    Nombre = reader.GetString("Nombre"),
                                    Clase = reader.GetString("NombreClase"),
                                    Nivel = reader.GetInt32("ID_Nivel"),
                                    Fuerza = reader.GetInt32("Fuerza"),
                                    Destreza = reader.GetInt32("Destreza"),
                                    Constitucion = reader.GetInt32("Constitucion"),
                                    Inteligencia = reader.GetInt32("Inteligencia"),
                                    Sabiduria = reader.GetInt32("Sabiduria"),
                                    Carisma = reader.GetInt32("Carisma"),
                                    VidaActual = reader.GetInt32("HP"),
                                    VidaMax = reader.GetInt32("HP"),
                                    Oro = reader.GetInt32("Oro"),
                                    Inventario = new List<Item>(),
                                    EquipoActual = new Equipo()
                                };
                            }
                            else
                            {
                                throw new Exception("No se encontró el jugador con ID: " + jugadorId);
                            }
                        }
                    }

                    // 2. Cargar inventario (items consumibles y equipables)
                    string queryInventario = @"
                        SELECT o.ID_Objeto, o.Nombre, o.Tipo, o.Efecto, o.Categoria, i.Cantidad,
                               COALESCE(i.Equipado, 0) as Equipado
                        FROM inventario i
                        INNER JOIN objeto o ON i.ID_Objeto = o.ID_Objeto
                        WHERE i.ID_Jugador = @id AND o.ID_Objeto != 51";

                    using (MySqlCommand cmd = new MySqlCommand(queryInventario, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string tipo = reader.GetString("Tipo");
                                string categoria = reader.IsDBNull(reader.GetOrdinal("Categoria")) ? "" : reader.GetString("Categoria");

                                Item item = new Item
                                {
                                    IdObjeto = reader.GetInt32("ID_Objeto"),
                                    Nombre = reader.GetString("Nombre"),
                                    Tipo = tipo,
                                    Categoria = categoria,
                                    Descripcion = $"Efecto: {reader.GetInt32("Efecto")}",
                                    BonVida = reader.GetInt32("Efecto"),
                                    Cantidad = reader.GetInt32("Cantidad"),
                                    Equipado = reader.GetInt32("Equipado") == 1
                                };

                                pj.Inventario.Add(item);

                                // Si está equipado, colocarlo en el equipo actual
                                if (item.Equipado)
                                {
                                    AsignarItemEquipado(item);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar personaje:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                pj = new PersonajeCompleto(); // Crear personaje vacío para evitar crashes
            }
        }

        private void AsignarItemEquipado(Item item)
        {
            if (item.Tipo == "Arma")
                pj.EquipoActual.Arma = item;
            else if (item.Tipo.Contains("Armadura"))
                pj.EquipoActual.Armadura = item;
            else if (item.Tipo == "Accesorio")
                pj.EquipoActual.Accesorio = item;
        }

        private void ConfigurarUI()
        {
            this.Text = "Inventario del Personaje";
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(40, 30, 20);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // Panel izquierdo - Estadísticas del personaje
            Panel panelIzquierdo = new Panel
            {
                Location = new Point(15, 15),
                Size = new Size(300, 580),
                BackColor = Color.FromArgb(60, 45, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            PictureBox pbImagen = new PictureBox
            {
                Location = new Point(50, 20),
                Size = new Size(200, 200),
                BorderStyle = BorderStyle.FixedSingle,
                SizeMode = PictureBoxSizeMode.StretchImage,
                BackColor = Color.DimGray
            };

            // Imagen placeholder
            Bitmap bmp = new Bitmap(200, 200);
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.DimGray);
                using (var f = new Font("Papyrus", 16, FontStyle.Bold))
                using (var br = new SolidBrush(Color.White))
                {
                    g.DrawString("PERSONAJE", f, br, new PointF(35, 90));
                }
            }
            pbImagen.Image = bmp;

            lblEstadisticas = new Label
            {
                Location = new Point(15, 235),
                Size = new Size(270, 280),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10),
                BackColor = Color.Transparent
            };

            lblOro = new Label
            {
                Location = new Point(15, 520),
                Size = new Size(270, 40),
                ForeColor = Color.Gold,
                Font = new Font("Papyrus", 14, FontStyle.Bold),
                BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleCenter
            };

            panelIzquierdo.Controls.Add(pbImagen);
            panelIzquierdo.Controls.Add(lblEstadisticas);
            panelIzquierdo.Controls.Add(lblOro);

            // Panel centro - Inventario
            Panel panelCentro = new Panel
            {
                Location = new Point(330, 15),
                Size = new Size(420, 580),
                BackColor = Color.FromArgb(60, 45, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblTituloInv = new Label
            {
                Text = "INVENTARIO",
                Font = new Font("Papyrus", 14, FontStyle.Bold),
                ForeColor = Color.Gold,
                Location = new Point(10, 10),
                AutoSize = true
            };

            listaItems = new ListView
            {
                Location = new Point(10, 45),
                Size = new Size(400, 420),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                BackColor = Color.FromArgb(240, 235, 220),
                Font = new Font("Segoe UI", 9),
                MultiSelect = false,
                HideSelection = false
            };
            listaItems.Columns.Add("Objeto", 200);
            listaItems.Columns.Add("Tipo", 100);
            listaItems.Columns.Add("Cantidad", 90);
            listaItems.SelectedIndexChanged += ListaItems_SelectedIndexChanged;
            listaItems.Click += (s, e) => ListaItems_SelectedIndexChanged(s, e);

            btnEquipar = CrearBotonConIcono("⚔ EQUIPAR", 10, 480, 130);
            btnUsar = CrearBotonConIcono("🧪 USAR", 145, 480, 130);
            btnDesequipar = CrearBotonConIcono("✖ DESEQUIPAR", 10, 525, 265);

            // Inicialmente deshabilitados
            btnEquipar.Enabled = false;
            btnUsar.Enabled = false;
            btnDesequipar.Enabled = false;

            btnEquipar.Click += BtnEquipar_Click;
            btnUsar.Click += BtnUsar_Click;
            btnDesequipar.Click += BtnDesequipar_Click;

            // BOTÓN DE DEBUG TEMPORAL
            Button btnDebug = new Button
            {
                Text = "🔍 INFO",
                Location = new Point(285, 480),
                Size = new Size(85, 35),
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                BackColor = Color.DarkOrange,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDebug.FlatAppearance.BorderColor = Color.Gold;
            btnDebug.Click += (s, e) =>
            {
                if (listaItems.SelectedItems.Count > 0)
                {
                    var item = listaItems.SelectedItems[0].Tag as Item;
                    bool esPocion = (item.IdObjeto >= 1 && item.IdObjeto <= 4) ||
                                   item.Nombre.ToLower().Contains("pocion");
                    MessageBox.Show(
                        $"📋 INFORMACIÓN DEL ITEM:\n\n" +
                        $"Nombre: {item.Nombre}\n" +
                        $"ID: {item.IdObjeto}\n" +
                        $"Tipo: '{item.Tipo}'\n" +
                        $"Categoría: '{item.Categoria}'\n" +
                        $"Cantidad: {item.Cantidad}\n" +
                        $"BonVida: {item.BonVida}\n" +
                        $"Equipado: {item.Equipado}\n\n" +
                        $"🔍 DETECCIÓN:\n" +
                        $"Es poción: {esPocion}\n\n" +
                        $"🎮 BOTONES:\n" +
                        $"Equipar: {btnEquipar.Enabled}\n" +
                        $"Usar: {btnUsar.Enabled}\n" +
                        $"Desequipar: {btnDesequipar.Enabled}",
                        "Debug - Item Info",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show("No hay ningún item seleccionado.", "Debug", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            };

            panelCentro.Controls.Add(lblTituloInv);
            panelCentro.Controls.Add(listaItems);
            panelCentro.Controls.Add(btnEquipar);
            panelCentro.Controls.Add(btnUsar);
            panelCentro.Controls.Add(btnDesequipar);
            panelCentro.Controls.Add(btnDebug); // Agregar botón debug

            // Panel derecho - Equipamiento
            panelEquipo = new Panel
            {
                Location = new Point(765, 15),
                Size = new Size(210, 580),
                BackColor = Color.FromArgb(60, 45, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblTituloEquipo = new Label
            {
                Text = "EQUIPAMIENTO",
                Font = new Font("Papyrus", 11, FontStyle.Bold),
                ForeColor = Color.Gold,
                Location = new Point(10, 10),
                AutoSize = false,
                Size = new Size(190, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label lblArma = new Label
            {
                Text = "Arma:",
                Font = new Font("Papyrus", 10, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(15, 60),
                AutoSize = true
            };

            lblArmaEquipada = new Label
            {
                Text = "Ninguna",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.LightGray,
                Location = new Point(15, 85),
                Size = new Size(180, 60),
                AutoSize = false
            };

            Label lblArmadura = new Label
            {
                Text = "Armadura:",
                Font = new Font("Papyrus", 10, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(15, 160),
                AutoSize = true
            };

            lblArmaduraEquipada = new Label
            {
                Text = "Ninguna",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.LightGray,
                Location = new Point(15, 185),
                Size = new Size(180, 60),
                AutoSize = false
            };

            Label lblAccesorio = new Label
            {
                Text = "Accesorio:",
                Font = new Font("Papyrus", 10, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(15, 260),
                AutoSize = true
            };

            lblAccesorioEquipado = new Label
            {
                Text = "Ninguno",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.LightGray,
                Location = new Point(15, 285),
                Size = new Size(180, 60),
                AutoSize = false
            };

            panelEquipo.Controls.Add(lblTituloEquipo);
            panelEquipo.Controls.Add(lblArma);
            panelEquipo.Controls.Add(lblArmaEquipada);
            panelEquipo.Controls.Add(lblArmadura);
            panelEquipo.Controls.Add(lblArmaduraEquipada);
            panelEquipo.Controls.Add(lblAccesorio);
            panelEquipo.Controls.Add(lblAccesorioEquipado);

            btnCerrar = new Button
            {
                Text = "CERRAR",
                Location = new Point(420, 600),
                Size = new Size(160, 40),
                Font = new Font("Papyrus", 12, FontStyle.Bold),
                BackColor = Color.DarkRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnCerrar.FlatAppearance.BorderColor = Color.Gold;
            btnCerrar.Click += (s, e) => this.Close();

            this.Controls.Add(panelIzquierdo);
            this.Controls.Add(panelCentro);
            this.Controls.Add(panelEquipo);
            this.Controls.Add(btnCerrar);
        }

        private Button CrearBoton(string texto, int x, int y, int ancho)
        {
            Button btn = new Button
            {
                Text = texto,
                Location = new Point(x, y),
                Size = new Size(ancho, 35),
                Font = new Font("Papyrus", 10, FontStyle.Bold),
                BackColor = Color.SaddleBrown,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btn.FlatAppearance.BorderColor = Color.Gold;
            return btn;
        }

        private Button CrearBotonConIcono(string texto, int x, int y, int ancho)
        {
            Button btn = new Button
            {
                Text = texto,
                Location = new Point(x, y),
                Size = new Size(ancho, 35),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                BackColor = Color.SaddleBrown,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = true, // CAMBIO: Siempre habilitado inicialmente para debug
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                TabStop = true
            };
            btn.FlatAppearance.BorderColor = Color.Gold;
            btn.FlatAppearance.BorderSize = 2;

            // Efecto hover
            btn.MouseEnter += (s, e) =>
            {
                Button button = s as Button;
                if (button != null && button.Enabled)
                {
                    button.BackColor = Color.FromArgb(139, 90, 43);
                }
            };
            btn.MouseLeave += (s, e) =>
            {
                Button button = s as Button;
                if (button != null)
                {
                    button.BackColor = button.Enabled ? Color.SaddleBrown : Color.FromArgb(100, 75, 50);
                }
            };

            return btn;
        }

        private void CargarDatosUI()
        {
            if (pj == null) return;

            lblEstadisticas.Text =
                $"━━━━━━━━━━━━━━━━━━━━━\n" +
                $"  {pj.Nombre}\n" +
                $"  {pj.Clase} - Nivel {pj.Nivel}\n" +
                $"━━━━━━━━━━━━━━━━━━━━━\n\n" +
                $"ATRIBUTOS:\n\n" +
                $"  Fuerza (STR):        {pj.Fuerza}\n" +
                $"  Destreza (DEX):      {pj.Destreza}\n" +
                $"  Constitución (CON):  {pj.Constitucion}\n" +
                $"  Inteligencia (INT):  {pj.Inteligencia}\n" +
                $"  Sabiduría (WIS):     {pj.Sabiduria}\n" +
                $"  Carisma (CHA):       {pj.Carisma}\n\n" +
                $"━━━━━━━━━━━━━━━━━━━━━\n\n" +
                $"  Vida: {pj.VidaActual}/{pj.VidaMax} PV";

            lblOro.Text = $"💰 {pj.Oro} ORO";

            listaItems.Items.Clear();
            if (pj.Inventario != null)
            {
                foreach (var it in pj.Inventario)
                {
                    var itv = new ListViewItem(it.Nombre ?? "Sin nombre");
                    itv.SubItems.Add(it.Tipo ?? "Sin tipo");
                    itv.SubItems.Add(it.Cantidad.ToString());
                    itv.Tag = it;
                    listaItems.Items.Add(itv);
                }
            }

            ActualizarEquipamiento();
        }

        private void ActualizarEquipamiento()
        {
            if (pj.EquipoActual.Arma != null)
                lblArmaEquipada.Text = $"{pj.EquipoActual.Arma.Nombre}\n{pj.EquipoActual.Arma.Descripcion}";
            else
                lblArmaEquipada.Text = "Ninguna";

            if (pj.EquipoActual.Armadura != null)
                lblArmaduraEquipada.Text = $"{pj.EquipoActual.Armadura.Nombre}\n{pj.EquipoActual.Armadura.Descripcion}";
            else
                lblArmaduraEquipada.Text = "Ninguna";

            if (pj.EquipoActual.Accesorio != null)
                lblAccesorioEquipado.Text = $"{pj.EquipoActual.Accesorio.Nombre}\n{pj.EquipoActual.Accesorio.Descripcion}";
            else
                lblAccesorioEquipado.Text = "Ninguno";
        }

        private void ListaItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count > 0)
            {
                var item = listaItems.SelectedItems[0].Tag as Item;

                if (item != null)
                {
                    // DEBUG: Mostrar info del item
                    string debugInfo = $"ITEM SELECCIONADO:\n" +
                                      $"Nombre: {item.Nombre}\n" +
                                      $"Tipo: {item.Tipo}\n" +
                                      $"Categoria: {item.Categoria}\n" +
                                      $"ID: {item.IdObjeto}";
                    System.Diagnostics.Debug.WriteLine(debugInfo);

                    // SIMPLIFICADO: Detectar poción por ID o nombre
                    bool esPocion = (item.IdObjeto >= 1 && item.IdObjeto <= 4) || // IDs de pociones
                                   item.Nombre.ToLower().Contains("pocion") ||
                                   item.Nombre.ToLower().Contains("curacion") ||
                                   item.Nombre.ToLower().Contains("curación") ||
                                   item.Tipo.ToLower().Contains("pocion"); // NUEVO: Incluir Tipo para mayor robustez

                    // Detectar equipable: todo lo que NO sea poción
                    bool esEquipable = !esPocion &&
                                      (item.IdObjeto >= 10 && item.IdObjeto <= 51); // Rango de armas/equipamiento

                    bool estaEquipado = EstaEquipado(item);

                    System.Diagnostics.Debug.WriteLine($"esPocion: {esPocion}, esEquipable: {esEquipable}");

                    // BOTÓN USAR - Solo pociones
                    btnUsar.Enabled = esPocion;
                    btnUsar.BackColor = btnUsar.Enabled ? Color.SaddleBrown : Color.FromArgb(100, 75, 50);
                    btnUsar.ForeColor = btnUsar.Enabled ? Color.White : Color.Gray;

                    // BOTÓN EQUIPAR - Solo equipables no equipados
                    btnEquipar.Enabled = esEquipable && !estaEquipado;
                    btnEquipar.BackColor = btnEquipar.Enabled ? Color.SaddleBrown : Color.FromArgb(100, 75, 50);
                    btnEquipar.ForeColor = btnEquipar.Enabled ? Color.White : Color.Gray;

                    // BOTÓN DESEQUIPAR - Solo si está equipado
                    btnDesequipar.Enabled = estaEquipado;
                    btnDesequipar.BackColor = btnDesequipar.Enabled ? Color.SaddleBrown : Color.FromArgb(100, 75, 50);
                    btnDesequipar.ForeColor = btnDesequipar.Enabled ? Color.White : Color.Gray;

                    System.Diagnostics.Debug.WriteLine($"BOTONES - Usar: {btnUsar.Enabled}, Equipar: {btnEquipar.Enabled}, Desequipar: {btnDesequipar.Enabled}");
                }
                else
                {
                    DeshabilitarTodosBotones();
                }
            }
            else
            {
                DeshabilitarTodosBotones();
            }
        }

        private void DeshabilitarTodosBotones()
        {
            btnEquipar.Enabled = false;
            btnEquipar.BackColor = Color.FromArgb(100, 75, 50);

            btnUsar.Enabled = false;
            btnUsar.BackColor = Color.FromArgb(100, 75, 50);

            btnDesequipar.Enabled = false;
            btnDesequipar.BackColor = Color.FromArgb(100, 75, 50);
        }

        private bool EstaEquipado(Item item)
        {
            return pj.EquipoActual.Arma == item ||
                   pj.EquipoActual.Armadura == item ||
                   pj.EquipoActual.Accesorio == item;
        }

        private void BtnEquipar_Click(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count == 0) return;

            var item = listaItems.SelectedItems[0].Tag as Item;

            if (item == null) return;

            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    // Desequipar el item anterior si existe
                    Item itemAnterior = null;
                    string mensajeDesequipado = "";

                    if (item.Tipo == "Arma")
                    {
                        itemAnterior = pj.EquipoActual.Arma;
                        pj.EquipoActual.Arma = item;
                    }
                    else if (item.Tipo.Contains("Armadura"))
                    {
                        itemAnterior = pj.EquipoActual.Armadura;
                        pj.EquipoActual.Armadura = item;
                    }
                    else if (item.Tipo == "Accesorio")
                    {
                        itemAnterior = pj.EquipoActual.Accesorio;
                        pj.EquipoActual.Accesorio = item;
                    }

                    // Actualizar BD - desequipar anterior (si existe columna Equipado)
                    if (itemAnterior != null)
                    {
                        try
                        {
                            string queryDesequipar = "UPDATE inventario SET Equipado = 0 WHERE ID_Jugador = @id AND ID_Objeto = @obj";
                            using (MySqlCommand cmd = new MySqlCommand(queryDesequipar, conexion))
                            {
                                cmd.Parameters.AddWithValue("@id", jugadorId);
                                cmd.Parameters.AddWithValue("@obj", itemAnterior.IdObjeto);
                                cmd.ExecuteNonQuery();
                            }
                        }
                        catch { /* Columna Equipado no existe, ignorar */ }

                        itemAnterior.Equipado = false;
                        mensajeDesequipado = $"\nSe desequipó: {itemAnterior.Nombre}";
                    }

                    // Actualizar BD - equipar nuevo (si existe columna Equipado)
                    try
                    {
                        string queryEquipar = "UPDATE inventario SET Equipado = 1 WHERE ID_Jugador = @id AND ID_Objeto = @obj";
                        using (MySqlCommand cmd = new MySqlCommand(queryEquipar, conexion))
                        {
                            cmd.Parameters.AddWithValue("@id", jugadorId);
                            cmd.Parameters.AddWithValue("@obj", item.IdObjeto);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    catch { /* Columna Equipado no existe, ignorar */ }

                    item.Equipado = true;

                    ActualizarEquipamiento();

                    // Refrescar la selección para actualizar botones
                    ListaItems_SelectedIndexChanged(null, null);

                    MessageBox.Show(
                        $"⚔ {item.Nombre} equipado!{mensajeDesequipado}",
                        "Equipo actualizado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al equipar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDesequipar_Click(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count == 0) return;

            var item = listaItems.SelectedItems[0].Tag as Item;

            if (item == null) return;

            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    // Actualizar BD (si existe columna Equipado)
                    try
                    {
                        string query = "UPDATE inventario SET Equipado = 0 WHERE ID_Jugador = @id AND ID_Objeto = @obj";
                        using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                        {
                            cmd.Parameters.AddWithValue("@id", jugadorId);
                            cmd.Parameters.AddWithValue("@obj", item.IdObjeto);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    catch { /* Columna Equipado no existe, ignorar */ }

                    // Desequipar del personaje
                    if (pj.EquipoActual.Arma == item) pj.EquipoActual.Arma = null;
                    if (pj.EquipoActual.Armadura == item) pj.EquipoActual.Armadura = null;
                    if (pj.EquipoActual.Accesorio == item) pj.EquipoActual.Accesorio = null;

                    item.Equipado = false;

                    ActualizarEquipamiento();

                    // Refrescar la selección para actualizar botones
                    ListaItems_SelectedIndexChanged(null, null);

                    MessageBox.Show(
                        $"✖ {item.Nombre} desequipado!",
                        "Equipo actualizado",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al desequipar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUsar_Click(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count == 0) return;

            var item = listaItems.SelectedItems[0].Tag as Item;

            if (item == null) return;

            // Verificar que sea una poción (usando la misma lógica robusta)
            bool esPocionUso = (item.IdObjeto >= 1 && item.IdObjeto <= 4) ||
                               item.Nombre.ToLower().Contains("pocion") ||
                               item.Nombre.ToLower().Contains("curacion") ||
                               item.Nombre.ToLower().Contains("curación") ||
                               item.Tipo.ToLower().Contains("pocion");

            if (!esPocionUso)
            {
                MessageBox.Show("Este objeto no se puede usar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    // Calcular nueva vida
                    int vidaAntes = pj.VidaActual;
                    pj.VidaActual += item.BonVida;
                    if (pj.VidaActual > pj.VidaMax)
                        pj.VidaActual = pj.VidaMax;

                    int vidaCurada = pj.VidaActual - vidaAntes;

                    // Actualizar HP del jugador en BD
                    string queryHP = "UPDATE jugador SET HP = @hp WHERE ID_Jugador = @id";
                    using (MySqlCommand cmd = new MySqlCommand(queryHP, conexion))
                    {
                        cmd.Parameters.AddWithValue("@hp", pj.VidaActual);
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        cmd.ExecuteNonQuery();
                    }

                    // Reducir cantidad en inventario
                    item.Cantidad--;

                    if (item.Cantidad <= 0)
                    {
                        // Eliminar item del inventario
                        string queryEliminar = "DELETE FROM inventario WHERE ID_Jugador = @id AND ID_Objeto = @obj";
                        using (MySqlCommand cmd = new MySqlCommand(queryEliminar, conexion))
                        {
                            cmd.Parameters.AddWithValue("@id", jugadorId);
                            cmd.Parameters.AddWithValue("@obj", item.IdObjeto);
                            cmd.ExecuteNonQuery();
                        }
                        pj.Inventario.Remove(item);
                    }
                    else
                    {
                        // Actualizar cantidad
                        string queryActualizar = "UPDATE inventario SET Cantidad = @cant WHERE ID_Jugador = @id AND ID_Objeto = @obj";
                        using (MySqlCommand cmd = new MySqlCommand(queryActualizar, conexion))
                        {
                            cmd.Parameters.AddWithValue("@cant", item.Cantidad);
                            cmd.Parameters.AddWithValue("@id", jugadorId);
                            cmd.Parameters.AddWithValue("@obj", item.IdObjeto);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    CargarDatosUI();
                    MessageBox.Show(
                        $"¡Has usado {item.Nombre}!\n\n" +
                        $"Vida restaurada: +{vidaCurada} PV\n" +
                        $"Vida actual: {pj.VidaActual}/{pj.VidaMax} PV",
                        "Poción consumida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al usar el objeto:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Clases de datos
        public class Item
        {
            public int IdObjeto { get; set; }
            public string Nombre { get; set; }
            public string Tipo { get; set; }
            public string Categoria { get; set; }
            public string Descripcion { get; set; }
            public int BonVida { get; set; }
            public int BonFuerza { get; set; }
            public int BonDestreza { get; set; }
            public int Cantidad { get; set; } = 1;
            public bool Equipado { get; set; } = false;
        }

        public class Equipo
        {
            public Item Arma { get; set; }
            public Item Armadura { get; set; }
            public Item Accesorio { get; set; }
        }

        public class PersonajeCompleto
        {
            public string Nombre { get; set; } = "Sin nombre";
            public string Clase { get; set; } = "Aventurero";
            public int Nivel { get; set; } = 1;
            public int Fuerza { get; set; } = 10;
            public int Destreza { get; set; } = 10;
            public int Constitucion { get; set; } = 10;
            public int Inteligencia { get; set; } = 10;
            public int Sabiduria { get; set; } = 10;
            public int Carisma { get; set; } = 10;
            public int VidaActual { get; set; } = 10;
            public int VidaMax { get; set; } = 10;
            public int Oro { get; set; } = 0;
            public Equipo EquipoActual { get; set; } = new Equipo();
            public List<Item> Inventario { get; set; } = new List<Item>();
            public Image ImagenPersonaje { get; set; }
        }
    }
}
