﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Proyecto_Dnd
{
    public partial class Form9 : Form
    {
        public static int JugadorIdActual { get; private set; }

        public Form9()
        {
            InitializeComponent();
            ConfigurarFormulario();
        }

        private void ConfigurarFormulario()
        {
            this.Text = "Dungeons & Dragons - Login";
            this.Size = new Size(450, 320);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(40, 30, 20);

            Panel panelPrincipal = new Panel
            {
                Size = new Size(400, 260),
                Location = new Point(25, 20),
                BackColor = Color.FromArgb(60, 45, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblTitulo = new Label
            {
                Text = "ACCESO A PARTIDA",
                Font = new Font("Papyrus", 16, FontStyle.Bold),
                ForeColor = Color.Gold,
                AutoSize = false,
                Size = new Size(360, 40),
                Location = new Point(20, 15),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label lblUsuario = new Label
            {
                Text = "Nombre de Jugador:",
                Font = new Font("Papyrus", 10),
                ForeColor = Color.White,
                Location = new Point(30, 70)
            };

            TextBox txtUsuario = new TextBox
            {
                Name = "txtUsuario",
                Location = new Point(30, 95),
                Width = 340,
                Height = 30,
                Font = new Font("Segoe UI", 11),
                BackColor = Color.FromArgb(240, 235, 220)
            };

            Label lblContrasena = new Label
            {
                Text = "Contraseña:",
                Font = new Font("Papyrus", 10),
                ForeColor = Color.White,
                Location = new Point(30, 135)
            };

            TextBox txtContrasena = new TextBox
            {
                Name = "txtContrasena",
                Location = new Point(30, 160),
                Width = 340,
                Height = 30,
                Font = new Font("Segoe UI", 11),
                PasswordChar = '●',
                BackColor = Color.FromArgb(240, 235, 220)
            };

            Button btnAcceder = new Button
            {
                Text = "CONTINUAR AVENTURA",
                Location = new Point(80, 205),
                Width = 240,
                Height = 40,
                Font = new Font("Papyrus", 11, FontStyle.Bold),
                BackColor = Color.SaddleBrown,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnAcceder.FlatAppearance.BorderColor = Color.Gold;
            btnAcceder.FlatAppearance.BorderSize = 2;

            btnAcceder.Click += (s, e) =>
            {
                string nombre = txtUsuario.Text.Trim();
                string contrasena = txtContrasena.Text;

                if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(contrasena))
                {
                    MessageBox.Show("Por favor, completa todos los campos.", "Campos vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int jugadorId = ValidarCredenciales(nombre, contrasena);

                if (jugadorId > 0)
                {
                    JugadorIdActual = jugadorId;
                    MessageBox.Show($"¡Bienvenido de vuelta, {nombre}!\nID de jugador: {jugadorId}", "Acceso concedido", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Form5 partida = new Form5();
                    partida.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.", "Error de acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            panelPrincipal.Controls.Add(lblTitulo);
            panelPrincipal.Controls.Add(lblUsuario);
            panelPrincipal.Controls.Add(txtUsuario);
            panelPrincipal.Controls.Add(lblContrasena);
            panelPrincipal.Controls.Add(txtContrasena);
            panelPrincipal.Controls.Add(btnAcceder);
            this.Controls.Add(panelPrincipal);
        }

        private void Form9_Load(object sender, EventArgs e)
        {
        }

        private int ValidarCredenciales(string nombre, string contrasena)
        {
            string cadenaConexion = "Server=localhost;Database=proyecto;Uid=root;Pwd=;";

            try
            {
                using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
                {
                    conexion.Open();

                    // Consulta directa para obtener el ID del jugador
                    string query = @"SELECT ID_Jugador 
                                    FROM jugador 
                                    WHERE Nombre = @nombre AND Contrasena = @contrasena 
                                    LIMIT 1";

                    using (MySqlCommand comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@nombre", nombre);
                        comando.Parameters.AddWithValue("@contrasena", contrasena);

                        object resultado = comando.ExecuteScalar();

                        if (resultado != null && resultado != DBNull.Value)
                        {
                            int idObtenido = Convert.ToInt32(resultado);
                            // Log para debugging
                            System.Diagnostics.Debug.WriteLine($"Login exitoso - Usuario: {nombre}, ID: {idObtenido}");
                            return idObtenido;
                        }

                        // Log para debugging
                        System.Diagnostics.Debug.WriteLine($"Login fallido - Usuario: {nombre}");
                        return 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al conectar con la base de datos:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }
    }
}