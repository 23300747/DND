﻿using System;
using System.Media;
using System.Windows.Forms;

namespace Proyecto_Dnd
{
    public partial class Form4 : Form
    {
        SoundPlayer narrador;


        public Form4()
        {
            InitializeComponent();
            ReproducirNarracion();
        }

        private void ReproducirNarracion()
        {  
               // narrador = new SoundPlayer("intro_tempestad.wav");
               // narrador.Play(); // Usa PlayLooping() si quieres que se repita
            Form5 Mp1 = new Form5();
            Mp1.Show();
            this.Hide();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (narrador != null)
            {
                narrador.Stop();
            }
            base.OnFormClosing(e);
        }
    }
}
