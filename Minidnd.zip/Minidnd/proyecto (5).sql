-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-11-2025 a las 04:21:11
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CargarPersonajeDesdeDB` (IN `jugadorId` INT)   BEGIN
    
    START TRANSACTION;

    
    SELECT j.ID_Jugador, j.Nombre, j.HP, j.Fuerza, j.Destreza,
           j.Constitucion, j.Inteligencia, j.Sabiduria, j.Carisma,
           j.ID_Nivel, j.ID_Clase, j.ID_Subraza,
           c.Nombre AS NombreClase, s.Nombre AS NombreRaza
    FROM jugador j
    LEFT JOIN clase c ON j.ID_Clase = c.ID_Clase
    LEFT JOIN subraza s ON j.ID_Subraza = s.ID_Subraza
    WHERE j.ID_Jugador = jugadorId;

    
    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CompletarMision` (IN `p_ID_Jugador` INT, IN `p_ID_Mision` INT, OUT `p_Resultado` VARCHAR(100))   BEGIN
    DECLARE v_Oro INT;
    DECLARE v_ID_Objeto INT;
    DECLARE v_EXP_Ganada INT;
    DECLARE v_Completado TINYINT;
    
    
    SELECT Completado INTO v_Completado
    FROM misiones
    WHERE ID_Misiones = p_ID_Mision;
    
    IF v_Completado = 1 THEN
        SET p_Resultado = 'Mision ya completada';
    ELSE
        
        SELECT Oro, ID_Objeto INTO v_Oro, v_ID_Objeto
        FROM misiones
        WHERE ID_Misiones = p_ID_Mision;
        
        
        SET v_EXP_Ganada = ROUND(v_Oro * 0.5);
        
        
        UPDATE misiones
        SET Completado = 1
        WHERE ID_Misiones = p_ID_Mision;
        
        
        UPDATE jugador
        SET Oro = Oro + v_Oro,
            EXP = EXP + v_EXP_Ganada
        WHERE ID_Jugador = p_ID_Jugador;
        
        
        UPDATE inventario
        SET Cantidad = Cantidad + v_Oro
        WHERE ID_Jugador = p_ID_Jugador AND ID_Objeto = 51;
        
        
        INSERT INTO inventario (ID_Jugador, ID_Objeto, Cantidad, Equipado)
        VALUES (p_ID_Jugador, v_ID_Objeto, 1, 0)
        ON DUPLICATE KEY UPDATE Cantidad = Cantidad + 1;
        
        
        CALL VerificarSubidaNivel(p_ID_Jugador);
        
        SET p_Resultado = 'Mision completada exitosamente';
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GuardarPersonaje` (IN `Nombre` VARCHAR(50), IN `Contrasena` VARCHAR(50), IN `ID_Clase` INT, IN `ID_Alineamiento` INT, IN `ID_Subraza` INT, IN `ID_Transfondo` INT, IN `HP` INT, IN `Fuerza` INT, IN `Sabiduria` INT, IN `Inteligencia` INT, IN `Constitucion` INT, IN `Destreza` INT, IN `Carisma` INT, IN `Iniciativa` INT)   BEGIN
    INSERT INTO Jugador (
        Nombre, Contrasena, ID_Clase, ID_Alineamiento, ID_Subraza, ID_Transfondo, ID_Nivel,
        HP, EXP, Fuerza, Sabiduria, Inteligencia, Constitucion, Destreza, Carisma, Iniciativa, Oro
    )
    VALUES (
        Nombre, Contrasena, ID_Clase, ID_Alineamiento, ID_Subraza, ID_Transfondo, 1,
        HP, 0, Fuerza, Sabiduria, Inteligencia, Constitucion, Destreza, Carisma, Iniciativa, 0
    );
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerDialogosNPC` (IN `p_ID_NPC` INT)   BEGIN
    SELECT 
        ID_DialogoNPC,
        Prioridad,
        Texto
    FROM dialogonpc
    WHERE ID_NPC = p_ID_NPC
    ORDER BY Prioridad;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ValidarCredenciales` (IN `nombreJugador` VARCHAR(100), IN `contrasenaJugador` VARCHAR(100))   BEGIN
    
    SELECT ID_Jugador
    FROM jugador
    WHERE Nombre = nombreJugador AND Contrasena = contrasenaJugador
    LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerificarSubidaNivel` (IN `p_ID_Jugador` INT)   BEGIN
    DECLARE v_EXP_Actual INT;
    DECLARE v_EXP_Necesaria INT;
    DECLARE v_Nivel_Actual INT;
    DECLARE v_Nuevo_Nivel INT;
    DECLARE v_HP_Adicional INT;
    DECLARE v_Dados_Golpe INT;
    DECLARE v_Constitucion INT;
    
    
    SELECT EXP, ID_Nivel, Constitucion INTO v_EXP_Actual, v_Nivel_Actual, v_Constitucion
    FROM jugador
    WHERE ID_Jugador = p_ID_Jugador;
    
    
    SELECT c.DadosGolpe INTO v_Dados_Golpe
    FROM jugador j
    INNER JOIN clase c ON j.ID_Clase = c.ID_Clase
    WHERE j.ID_Jugador = p_ID_Jugador;
    
    
    SELECT ID_Nivel INTO v_Nuevo_Nivel
    FROM nivel
    WHERE EXPNecesaria <= v_EXP_Actual
    ORDER BY ID_Nivel DESC
    LIMIT 1;
    
    IF v_Nuevo_Nivel > v_Nivel_Actual THEN
        
        SET v_HP_Adicional = v_Dados_Golpe + v_Constitucion;
        
        
        UPDATE jugador
        SET ID_Nivel = v_Nuevo_Nivel,
            HP = HP + v_HP_Adicional
        WHERE ID_Jugador = p_ID_Jugador;
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alineamiento`
--

CREATE TABLE `alineamiento` (
  `ID_Alineamiento` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Descripcion` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `alineamiento`
--

INSERT INTO `alineamiento` (`ID_Alineamiento`, `Nombre`, `Descripcion`) VALUES
(1, 'Legal Bueno', 'Vinculado a juramentos antiguos, su justicia es eco de un reino caido'),
(2, 'Neutral Bueno', 'Camina entre ruinas, guiado por compasion sin ley ni corona'),
(3, 'Caotico Bueno', 'Rompe cadenas por almas perdidas, aunque el mundo lo llame traidor'),
(4, 'Legal Neutral', 'Sirve ordenes olvidadas, indiferente al dolor o la redencion'),
(5, 'Neutral Puro', 'Equilibrio encarnado, como piedra que observa sin juicio'),
(6, 'Caotico Neutral', 'Errante sin causa, su voluntad danza con el viento y la ruina'),
(7, 'Legal Malvado', 'Obedece leyes crueles, donde el orden es instrumento de sometimiento'),
(8, 'Neutral Malvado', 'Busca poder en cenizas, sin lealtad ni piedad, como sombra que devora'),
(9, 'Caotico Malvado', 'Arde en caos y destruccion, como heraldo de tormentas sin nombre');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atributosgen`
--

CREATE TABLE `atributosgen` (
  `ID_Atributo` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `atributosgen`
--

INSERT INTO `atributosgen` (`ID_Atributo`, `Nombre`, `Descripcion`) VALUES
(1, 'Fuerza', 'Poder bruto que rompe sellos, puertas y voluntades'),
(2, 'Destreza', 'Agilidad precisa, como filo que danza entre ruinas'),
(3, 'Constitucion', 'Resistencia forjada en dolor, cicatrices y hierro'),
(4, 'Inteligencia', 'Memoria de eras perdidas, dominio de lo arcano'),
(5, 'Sabiduria', 'Percepcion del abismo, juicio entre sombras y ecos'),
(6, 'Carisma', 'Presencia que invoca pactos, doblega almas y destinos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase`
--

CREATE TABLE `clase` (
  `ID_Clase` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL,
  `DadosGolpe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clase`
--

INSERT INTO `clase` (`ID_Clase`, `Nombre`, `Descripcion`, `DadosGolpe`) VALUES
(1, 'Guerrero', 'Combatiente versatil experto en armas y armaduras', 10),
(2, 'Mago', 'Usuario de magia arcana con gran poder ofensivo', 6),
(3, 'Paladin', 'Se lo que se conoce como una fuerza', 8),
(4, 'Clerigo', 'Sanador y protector con magia divina', 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clase_habilidades`
--

CREATE TABLE `clase_habilidades` (
  `ID_ClHa` int(11) NOT NULL,
  `Competente` tinyint(1) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `ID_Clase` int(11) NOT NULL,
  `ID_Habilidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clase_habilidades`
--

INSERT INTO `clase_habilidades` (`ID_ClHa`, `Competente`, `Cantidad`, `ID_Clase`, `ID_Habilidad`) VALUES
(1, 1, 1, 1, 1),
(2, 1, 1, 1, 2),
(3, 1, 1, 1, 3),
(4, 1, 1, 1, 4),
(5, 1, 1, 2, 5),
(6, 1, 1, 2, 6),
(7, 1, 1, 2, 7),
(8, 1, 1, 2, 8),
(9, 1, 1, 3, 9),
(10, 1, 1, 3, 10),
(11, 1, 1, 3, 11),
(12, 1, 1, 3, 12),
(13, 1, 1, 4, 13),
(14, 1, 1, 4, 14),
(15, 1, 1, 4, 15),
(16, 1, 1, 4, 16);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conjuros`
--

CREATE TABLE `conjuros` (
  `ID_Conjuro` int(11) NOT NULL,
  `ID_Clase` int(11) NOT NULL,
  `ID_Hechizo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `conjuros`
--

INSERT INTO `conjuros` (`ID_Conjuro`, `ID_Clase`, `ID_Hechizo`) VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3),
(4, 2, 7),
(5, 2, 8),
(6, 2, 9),
(7, 2, 13),
(8, 2, 14),
(9, 2, 15),
(10, 4, 3),
(11, 4, 4),
(12, 4, 5),
(13, 4, 6),
(14, 4, 10),
(15, 4, 11),
(16, 4, 16),
(17, 4, 17),
(18, 4, 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dialogonpc`
--

CREATE TABLE `dialogonpc` (
  `ID_DialogoNPC` int(11) NOT NULL,
  `Prioridad` int(11) NOT NULL,
  `Texto` text NOT NULL,
  `ID_NPC` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `dialogonpc`
--

INSERT INTO `dialogonpc` (`ID_DialogoNPC`, `Prioridad`, `Texto`, `ID_NPC`) VALUES
(1, 1, 'Bienvenido al Retiro del Dragon, viajero. Aqui encontraras paz y sabiduria.', 1),
(2, 2, 'Los zombis han vuelto a aparecer en la playa. Necesitamos tu ayuda.', 1),
(3, 3, 'Has demostrado tu valor. Permiteme contarte sobre mi verdadera forma...', 1),
(4, 1, 'Necesito hongos con sombrero de corazon de las cuevas. ?Puedes ayudarme?', 2),
(5, 2, 'Estos hongos son perfectos. Dejame prepararte unas pociones.', 2),
(6, 1, 'Fui general de los Lobos Celestes. Ahora busco redencion en este lugar.', 3),
(7, 2, 'Vi el barco estrellarse contra las rocas. Algo no esta bien ahi.', 3),
(8, 1, 'Mis hermanos Mek y Minn sirven a ese dragon azul. Espero que esten bien.', 4),
(9, 2, 'Puedo venderte suministros y equipo. Echa un vistazo a mi inventario.', 4),
(10, 1, 'Los gases toxicos nos estan envenenando. Ayudanos, por favor.', 5),
(11, 2, 'Gracias por abrir el respiradero. Ahora podemos respirar de nuevo.', 5),
(12, 1, 'Rechace las ensenanzas de paz de Runara. Ahora soy prisionero de Chispa Fulminante.', 6),
(13, 2, 'Gracias por liberarme. Regresare con Runara y reflexionare sobre mis acciones.', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enemigo`
--

CREATE TABLE `enemigo` (
  `ID_Enemigo` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `HP` int(11) NOT NULL,
  `Fuerza` int(11) NOT NULL,
  `Sabiduria` int(11) NOT NULL,
  `Inteligencia` int(11) NOT NULL,
  `Constitucion` int(11) NOT NULL,
  `Destreza` int(11) NOT NULL,
  `Carisma` int(11) NOT NULL,
  `Iniciativa` int(11) NOT NULL,
  `Nivel` int(11) NOT NULL,
  `ID_Transfondo` int(11) NOT NULL,
  `ID_Clase` int(11) NOT NULL,
  `ID_Subraza` int(11) NOT NULL,
  `ID_Objeto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `enemigo`
--

INSERT INTO `enemigo` (`ID_Enemigo`, `Nombre`, `HP`, `Fuerza`, `Sabiduria`, `Inteligencia`, `Constitucion`, `Destreza`, `Carisma`, `Iniciativa`, `Nivel`, `ID_Transfondo`, `ID_Clase`, `ID_Subraza`, `ID_Objeto`) VALUES
(1, 'Zombi', 22, 13, 6, 3, 16, 6, 5, -2, 1, 5, 4, 8, 51),
(3, 'Serpiente de Fuego', 22, 12, 10, 7, 11, 14, 10, 2, 1, 6, 2, 7, 51),
(5, 'Oso Lechuza', 59, 20, 13, 3, 17, 12, 7, 1, 3, 7, 1, 9, 51),
(6, 'Pulpo Siervo Espora', 52, 17, 6, 2, 13, 13, 1, 1, 3, 6, 4, 5, 51),
(7, 'Miconido Adulto', 22, 10, 10, 10, 12, 10, 13, 0, 1, 4, 4, 7, 51),
(12, 'Hongo Violeta', 18, 3, 3, 1, 10, 1, 1, -5, 1, 4, 4, 7, 51),
(13, 'Kobold', 5, 7, 7, 8, 9, 15, 8, 2, 1, 5, 3, 3, 51),
(14, 'Estirge', 2, 4, 8, 2, 11, 16, 6, 3, 1, 7, 1, 9, 51),
(15, 'Gul', 22, 13, 10, 7, 10, 15, 6, 2, 1, 5, 4, 8, 51),
(16, 'Cria de Dragon Azul', 52, 17, 11, 12, 15, 10, 15, 0, 3, 8, 1, 6, 51),
(17, 'Cria de Dragon de Bronce', 32, 17, 11, 12, 15, 10, 15, 0, 2, 8, 1, 6, 51),
(18, 'Runara (Dragona de Bronce Adulta)', 212, 25, 15, 16, 23, 10, 19, 0, 13, 8, 2, 6, 51),
(19, 'Arpia', 38, 12, 10, 7, 12, 13, 13, 1, 1, 5, 3, 9, 51),
(20, 'Draco de Humo', 22, 6, 10, 6, 12, 14, 11, 2, 1, 6, 2, 7, 51);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habilidades`
--

CREATE TABLE `habilidades` (
  `ID_Habilidades` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `habilidades`
--

INSERT INTO `habilidades` (`ID_Habilidades`, `Nombre`, `Descripcion`) VALUES
(1, 'Golpe Demoledor', 'Ataque devastador que parte armaduras y huesos. Concentra toda la fuerza en un solo golpe mortal. Dano: 30'),
(2, 'Tajo Giratorio', 'Gira con el arma extendida atacando a todos los enemigos cercanos. Perfecto contra multiples oponentes. Dano: 20'),
(3, 'Estocada Precisa', 'Ataque quirurgico que encuentra puntos debiles en la defensa enemiga. Ignora parte de la armadura. Dano: 28'),
(4, 'Furia del Titan', 'Canaliza ira primordial aumentando temporalmente todo el dano fisico infligido. Duracion: 3 turnos'),
(5, 'Bola de Fuego', 'Esfera explosiva de llamas que incinera todo en un area. Clasico destructor arcano. Dano: 40'),
(6, 'Rayo Congelante', 'Lanza un rayo de hielo absoluto que congela y atraviesa enemigos. Puede ralentizar. Dano: 35'),
(7, 'Meteoro', 'Invoca una roca flamigera del cosmos que impacta con furia celestial. Magia devastadora. Dano: 55'),
(8, 'Barrera Arcana', 'Teje escudo magico de pura energia que absorbe dano entrante. Proteccion: 40 HP'),
(9, 'Golpe Divino', 'Ataque imbuido con poder celestial que castiga a los impios. Efectivo contra no-muertos. Dano: 32'),
(10, 'Juicio Celestial', 'Condena divina que invoca la ira de los dioses sobre el enemigo. Luz purificadora. Dano: 38'),
(11, 'Escudo de Fe', 'Proyecta proteccion divina que envuelve a aliados cercanos. Aumenta defensa del grupo. Duracion: 3 turnos'),
(12, 'Curacion Sagrada', 'Canaliza poder divino para cerrar heridas y restaurar vitalidad. Toque bendito. Curacion: 30 HP'),
(13, 'Luz Purificadora', 'Dano radiante sagrado que quema la oscuridad y debilita no-muertos. Resplandor divino. Dano: 35'),
(14, 'Palabra de Curacion', 'Pronuncia oracion sagrada que sana heridas instantaneamente. Milagro menor. Curacion: 40 HP'),
(15, 'Castigo Divino', 'Desata ira celestial contra enemigos impios. Martillo del juicio divino. Dano: 33'),
(16, 'Bendicion Masiva', 'Invoca gracia divina que mejora capacidades de combate de todo el grupo. Duracion: 4 turnos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hechizo`
--

CREATE TABLE `hechizo` (
  `ID_Hechizo` int(11) NOT NULL,
  `Nombre` varchar(100) DEFAULT NULL,
  `Descripcion` varchar(100) DEFAULT NULL,
  `DMG` int(11) NOT NULL,
  `ID_Nivel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hechizo`
--

INSERT INTO `hechizo` (`ID_Hechizo`, `Nombre`, `Descripcion`, `DMG`, `ID_Nivel`) VALUES
(1, 'Proyectil Magico', 'Dardos de energia que siempre impactan', 12, 1),
(2, 'Escudo Arcano', 'Genera barrera protectora', 0, 1),
(3, 'Detectar Magia', 'Revela objetos y seres magicos', 0, 1),
(4, 'Curar Heridas', 'Restaura puntos de vida', -15, 1),
(5, 'Bendicion', 'Mejora ataques de aliados', 0, 1),
(6, 'Luz Sagrada', 'Crea iluminacion divina', 0, 1),
(7, 'Esfera Flamigera', 'Bola de fuego concentrada', 25, 2),
(8, 'Rayo de Hielo', 'Lanza proyectil congelante', 22, 2),
(9, 'Invisibilidad', 'Vuelve invisible al objetivo', 0, 2),
(10, 'Restauracion Menor', 'Cura heridas moderadas', -25, 2),
(11, 'Arma Espiritual', 'Crea arma magica flotante', 18, 2),
(12, 'Inmovilizar Persona', 'Paraliza a un humanoide', 0, 2),
(13, 'Bola de Fuego', 'Explosion masiva de llamas', 35, 3),
(14, 'Rayo', 'Descarga electrica devastadora', 33, 3),
(15, 'Volar', 'Otorga capacidad de vuelo', 0, 3),
(16, 'Revivir', 'Resucita a un aliado caido', 0, 3),
(17, 'Proteccion Contra Energia', 'Resistencia elemental', 0, 3),
(18, 'Luz del Dia', 'Iluminacion intensa y sagrada', 0, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `ID_Inventario` int(11) NOT NULL,
  `Carga_Actual` int(11) NOT NULL,
  `Carga_Maxima` int(11) NOT NULL,
  `ID_Jugador` int(11) NOT NULL,
  `ID_Objeto` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL DEFAULT 1,
  `Equipado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`ID_Inventario`, `Carga_Actual`, `Carga_Maxima`, `ID_Jugador`, `ID_Objeto`, `Cantidad`, `Equipado`) VALUES
(0, 0, 100, 18, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugador`
--

CREATE TABLE `jugador` (
  `ID_Jugador` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `HP` int(11) NOT NULL,
  `EXP` int(11) NOT NULL,
  `Fuerza` int(11) NOT NULL,
  `Sabiduria` int(11) NOT NULL,
  `Inteligencia` int(11) NOT NULL,
  `Constitucion` int(11) NOT NULL,
  `Destreza` int(11) NOT NULL,
  `Carisma` int(11) NOT NULL,
  `Iniciativa` int(11) NOT NULL,
  `Oro` int(11) NOT NULL,
  `ID_Alineamiento` int(11) NOT NULL,
  `ID_Nivel` int(11) NOT NULL,
  `ID_Clase` int(11) NOT NULL,
  `ID_Transfondo` int(11) NOT NULL,
  `ID_Subraza` int(11) NOT NULL,
  `Contrasena` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `jugador`
--

INSERT INTO `jugador` (`ID_Jugador`, `Nombre`, `HP`, `EXP`, `Fuerza`, `Sabiduria`, `Inteligencia`, `Constitucion`, `Destreza`, `Carisma`, `Iniciativa`, `Oro`, `ID_Alineamiento`, `ID_Nivel`, `ID_Clase`, `ID_Transfondo`, `ID_Subraza`, `Contrasena`) VALUES
(18, 'a', 10, 0, 16, 15, 8, 15, 8, 10, 2, 500, 3, 1, 4, 4, 2, 'a'),
(21, 'a', 9, 0, 17, 15, 9, 17, 6, 12, -2, 0, 1, 1, 4, 1, 1, 'a1'),
(22, 'a', 7, 0, 9, 10, 17, 13, 15, 8, 4, 0, 2, 1, 2, 2, 1, 'rr');

--
-- Disparadores `jugador`
--
DELIMITER $$
CREATE TRIGGER `ActualizarOroInventario` AFTER UPDATE ON `jugador` FOR EACH ROW BEGIN
    IF NEW.Oro != OLD.Oro THEN
        UPDATE inventario
        SET Cantidad = NEW.Oro
        WHERE ID_Jugador = NEW.ID_Jugador AND ID_Objeto = 51;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mapa`
--

CREATE TABLE `mapa` (
  `ID_Mapa` int(11) NOT NULL,
  `Bloqueado` tinyint(1) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `misiones`
--

CREATE TABLE `misiones` (
  `ID_Misiones` int(11) NOT NULL,
  `Oro` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Bloqueado` tinyint(1) NOT NULL,
  `Completado` tinyint(1) NOT NULL,
  `ID_Objeto` int(11) NOT NULL,
  `ID_Mapa` int(11) NOT NULL,
  `ID_NPC` int(11) NOT NULL,
  `ID_Enemigo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel`
--

CREATE TABLE `nivel` (
  `ID_Nivel` int(11) NOT NULL,
  `BonusCompetencia` int(11) NOT NULL,
  `EXPNecesaria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `nivel`
--

INSERT INTO `nivel` (`ID_Nivel`, `BonusCompetencia`, `EXPNecesaria`) VALUES
(1, 2, 0),
(2, 2, 60),
(3, 2, 180),
(4, 2, 540),
(5, 3, 1300),
(6, 3, 2800),
(7, 3, 4600),
(8, 3, 6800),
(9, 4, 9600),
(10, 4, 12800),
(11, 4, 17000),
(12, 4, 20000),
(13, 5, 24000),
(14, 5, 28000),
(15, 5, 33000),
(16, 5, 39000),
(17, 6, 45000),
(18, 6, 53000),
(19, 6, 61000),
(20, 6, 71000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `npc`
--

CREATE TABLE `npc` (
  `ID_NPC` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `npc`
--

INSERT INTO `npc` (`ID_NPC`, `Nombre`) VALUES
(1, 'Runara la Anciana'),
(2, 'Tarak el Herbolario'),
(3, 'Varnoth la Veterana'),
(4, 'Myla la Kobold Manitas'),
(5, 'Sinensa el Miconido'),
(6, 'Aidron el Dragon de Bronce');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `objeto`
--

CREATE TABLE `objeto` (
  `ID_Objeto` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Peso` int(11) NOT NULL,
  `Efecto` int(11) NOT NULL,
  `Danio` varchar(20) DEFAULT NULL,
  `TipoDanio` varchar(20) DEFAULT NULL,
  `Requisitos` varchar(100) DEFAULT NULL,
  `Afectado` varchar(20) NOT NULL,
  `Precio` int(11) NOT NULL,
  `DistanciaUso` int(11) NOT NULL,
  `Categoria` varchar(20) NOT NULL,
  `Tipo` enum('Arma','Hechizo','Pocion','Equipamiento') NOT NULL DEFAULT 'Equipamiento',
  `Rareza` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `objeto`
--

INSERT INTO `objeto` (`ID_Objeto`, `Nombre`, `Peso`, `Efecto`, `Danio`, `TipoDanio`, `Requisitos`, `Afectado`, `Precio`, `DistanciaUso`, `Categoria`, `Tipo`, `Rareza`) VALUES
(1, 'Pocion de Curacion Menor', 1, 25, NULL, NULL, NULL, 'Portador', 50, 0, 'Pocion', 'Equipamiento', 'Comun'),
(2, 'Pocion de Curacion', 1, 50, NULL, NULL, NULL, 'Portador', 100, 0, 'Pocion', 'Equipamiento', 'Comun'),
(3, 'Pocion de Curacion Mayor', 1, 100, NULL, NULL, NULL, 'Portador', 200, 0, 'Pocion', 'Equipamiento', 'Infrecuente'),
(4, 'Pocion de Curacion Superior', 1, 200, NULL, NULL, NULL, 'Portador', 400, 0, 'Pocion', 'Equipamiento', 'Rara'),
(10, 'Daga Oxidada', 2, 8, NULL, NULL, NULL, 'Enemigo', 30, 5, 'Arma', 'Equipamiento', 'Comun'),
(11, 'Espada Corta de Acero', 3, 15, NULL, NULL, NULL, 'Enemigo', 100, 5, 'Arma', 'Equipamiento', 'Comun'),
(12, 'Espada Larga Forjada', 6, 25, NULL, NULL, NULL, 'Enemigo', 200, 5, 'Arma', 'Equipamiento', 'Infrecuente'),
(13, 'Espada Larga Runica', 6, 35, NULL, NULL, NULL, 'Enemigo', 400, 5, 'Arma', 'Equipamiento', 'Rara'),
(14, 'Hacha de Mano', 4, 12, NULL, NULL, NULL, 'Enemigo', 60, 5, 'Arma', 'Equipamiento', 'Comun'),
(15, 'Hacha de Guerra Ligera', 5, 20, NULL, NULL, NULL, 'Enemigo', 150, 5, 'Arma', 'Equipamiento', 'Infrecuente'),
(16, 'Gran Hacha', 10, 30, NULL, NULL, NULL, 'Enemigo', 250, 5, 'Arma', 'Equipamiento', 'Infrecuente'),
(17, 'Hacha del Berserker', 12, 42, NULL, NULL, NULL, 'Enemigo', 500, 5, 'Arma', 'Equipamiento', 'Rara'),
(18, 'Arco Corto Simple', 2, 10, NULL, NULL, NULL, 'Enemigo', 50, 40, 'Arma', 'Equipamiento', 'Comun'),
(19, 'Arco Corto Compuesto', 3, 18, NULL, NULL, NULL, 'Enemigo', 120, 40, 'Arma', 'Equipamiento', 'Comun'),
(20, 'Arco Largo de Tejo', 4, 26, NULL, NULL, NULL, 'Enemigo', 220, 80, 'Arma', 'Equipamiento', 'Infrecuente'),
(21, 'Arco Largo Elfico', 4, 38, NULL, NULL, NULL, 'Enemigo', 450, 80, 'Arma', 'Equipamiento', 'Rara'),
(22, 'Vara de Llamas', 3, 15, NULL, NULL, NULL, 'Enemigo', 100, 30, 'Arma', 'Equipamiento', 'Comun'),
(23, 'Baston del Infierno', 5, 28, NULL, NULL, NULL, 'Enemigo', 250, 30, 'Arma', 'Equipamiento', 'Infrecuente'),
(24, 'Vara Glacial', 3, 14, NULL, NULL, NULL, 'Enemigo', 110, 30, 'Arma', 'Equipamiento', 'Comun'),
(25, 'Baston del Invierno Eterno', 5, 32, NULL, NULL, NULL, 'Enemigo', 400, 30, 'Arma', 'Equipamiento', 'Rara'),
(51, 'Oro', 0, 0, NULL, NULL, NULL, 'Portador', 1, 0, 'Recurso', 'Equipamiento', 'Comun');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `raza`
--

CREATE TABLE `raza` (
  `ID_Raza` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL,
  `Velocidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `raza`
--

INSERT INTO `raza` (`ID_Raza`, `Nombre`, `Descripcion`, `Velocidad`) VALUES
(1, 'Elfo', 'Seres agiles y antiguos, afinados con la magia y los bosques', 30),
(2, 'Enano', 'Robustos y tenaces, maestros de la forja y la piedra', 25),
(3, 'Humano', 'Versatiles y ambiciosos, capaces de grandes logros o ruinas', 30),
(4, 'Mediano', 'Pequenos y sigilosos, expertos en evitar el peligro', 25),
(5, 'Semielfo', 'Hibridos con carisma y herencia dividida entre dos mundos', 30),
(6, 'Semiorco', 'Fuerza brutal y espiritu indomito, nacidos para la batalla', 30),
(7, 'Tiefling', 'Marcados por sangre infernal, portadores de magia oscura', 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stock`
--

CREATE TABLE `stock` (
  `ID_Stock` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `MultiplicadorPrecio` float NOT NULL,
  `ID_Objeto` int(11) NOT NULL,
  `ID_Tienda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `stock`
--

INSERT INTO `stock` (`ID_Stock`, `Cantidad`, `MultiplicadorPrecio`, `ID_Objeto`, `ID_Tienda`) VALUES
(1, 19, 1, 1, 1),
(2, 15, 1, 2, 1),
(3, 10, 1, 3, 1),
(4, 5, 1.2, 10, 1),
(5, 5, 1.2, 11, 1),
(6, 4, 1.2, 14, 1),
(7, 4, 1.2, 18, 1),
(8, 3, 1.2, 22, 1),
(9, 3, 1.2, 24, 1),
(10, 29, 0.8, 1, 2),
(11, 20, 0.9, 2, 2),
(12, 10, 1, 3, 2),
(13, 5, 1.1, 11, 2),
(14, 5, 1.1, 14, 2),
(15, 5, 1.1, 18, 2),
(16, 8, 1.3, 2, 3),
(17, 5, 1.3, 3, 3),
(18, 3, 1.4, 12, 3),
(19, 3, 1.4, 15, 3),
(20, 3, 1.4, 19, 3),
(21, 2, 1.4, 20, 3),
(22, 2, 1.4, 23, 3),
(23, 5, 1.8, 3, 4),
(24, 3, 1.8, 4, 4),
(25, 2, 1.5, 13, 4),
(26, 2, 1.5, 17, 4),
(27, 2, 1.5, 21, 4),
(28, 2, 1.6, 25, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subraza`
--

CREATE TABLE `subraza` (
  `ID_Subraza` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL,
  `ID_Raza` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `subraza`
--

INSERT INTO `subraza` (`ID_Subraza`, `Nombre`, `Descripcion`, `ID_Raza`) VALUES
(1, 'Alto Elfo', 'Portadores de luz ancestral, dominan la magia con elegancia fria', 1),
(2, 'Elfo Oscuro', 'Criaturas de sombras y rencor, su magia nace del dolor', 1),
(3, 'Enano de las Montanas', 'Forjados en piedra dura, resistentes como las cumbres que habitan', 2),
(4, 'Enano de las Colinas', 'Sabios y firmes, guardianes de secretos bajo tierra', 2),
(5, 'Humano', 'Sin linaje arcano, pero con voluntad capaz de romper destinos', 3),
(6, 'Mediano', 'Pequenos viajeros que burlan el peligro con astucia y suerte', 4),
(7, 'Semielfo', 'Errantes entre dos mundos, con mirada nostalgica y corazon dividido', 5),
(8, 'Semiorco', 'Hijos del conflicto, su furia es su escudo y su condena', 6),
(9, 'Tiefling', 'Herederos de pactos oscuros, su sangre arde con magia prohibida', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tienda`
--

CREATE TABLE `tienda` (
  `ID_Tienda` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `ID_Mapa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transfondo`
--

CREATE TABLE `transfondo` (
  `ID_Transfondo` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `transfondo`
--

INSERT INTO `transfondo` (`ID_Transfondo`, `Nombre`, `Descripcion`) VALUES
(1, 'Erudito', 'Portador de saberes rotos, su mente arde con verdades prohibidas. Conoce secretos arcanos y textos a'),
(2, 'Soldado', 'Forjado en batallas sin gloria, su acero recuerda nombres olvidados. Veterano de conflictos que marc'),
(3, 'Acolito', 'Servidor de dioses muertos, su fe es eco de un templo derrumbado. Mantiene rituales que otros consid'),
(4, 'Criminal', 'Marcado por pactos rotos, su pasado acecha en cada sombra. Huy? del crimen pero las deudas del infra'),
(5, 'Noble', 'Herencia maldita, su linaje sangra entre ruinas y traiciones. Noble de casa caida que busca restaura'),
(6, 'Cazador', 'Errante entre bestias, su mirada conoce la furia del bosque y la tumba. Rastrea presas en tierras sa'),
(7, 'Exiliado', 'Desterrado por crimen o verdad, su camino es ceniza y arrepentimiento. Busca redencion en un mundo q'),
(8, 'Profanador', 'Toco lo prohibido, y ahora el mundo lo rechaza como heraldo de ruina. Sus manos despertaron fuerzas ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trasfondo_habilidades`
--

CREATE TABLE `trasfondo_habilidades` (
  `ID_TH` int(11) NOT NULL,
  `Competente` tinyint(1) NOT NULL,
  `ID_Transfondo` int(11) NOT NULL,
  `ID_Habilidades` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `trasfondo_habilidades`
--

INSERT INTO `trasfondo_habilidades` (`ID_TH`, `Competente`, `ID_Transfondo`, `ID_Habilidades`) VALUES
(1, 1, 1, 5),
(2, 1, 1, 7),
(3, 1, 2, 1),
(4, 1, 2, 2),
(5, 1, 3, 13),
(6, 1, 3, 14),
(7, 1, 4, 3),
(8, 1, 5, 11),
(9, 1, 5, 16),
(10, 1, 6, 3),
(11, 1, 7, 4),
(12, 1, 8, 6);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alineamiento`
--
ALTER TABLE `alineamiento`
  ADD PRIMARY KEY (`ID_Alineamiento`);

--
-- Indices de la tabla `atributosgen`
--
ALTER TABLE `atributosgen`
  ADD PRIMARY KEY (`ID_Atributo`);

--
-- Indices de la tabla `clase`
--
ALTER TABLE `clase`
  ADD PRIMARY KEY (`ID_Clase`);

--
-- Indices de la tabla `clase_habilidades`
--
ALTER TABLE `clase_habilidades`
  ADD PRIMARY KEY (`ID_ClHa`),
  ADD KEY `ClHa_ID_Clase` (`ID_Clase`),
  ADD KEY `ClHa_ID_Habilidad` (`ID_Habilidad`);

--
-- Indices de la tabla `conjuros`
--
ALTER TABLE `conjuros`
  ADD PRIMARY KEY (`ID_Conjuro`),
  ADD KEY `Conjuros_ID_Clase_Clase_ID_Clase` (`ID_Clase`),
  ADD KEY `Conjuros_ID_Hechizo_Hechizo_ID_Hechizo` (`ID_Hechizo`);

--
-- Indices de la tabla `dialogonpc`
--
ALTER TABLE `dialogonpc`
  ADD PRIMARY KEY (`ID_DialogoNPC`),
  ADD KEY `DialogoNPC_ID_NPC_NPC_ID_NPC` (`ID_NPC`);

--
-- Indices de la tabla `enemigo`
--
ALTER TABLE `enemigo`
  ADD PRIMARY KEY (`ID_Enemigo`),
  ADD KEY `Enemigo_Nivel_Nivel_ID_Nivel` (`Nivel`),
  ADD KEY `Enemigo_ID_Transfondo_Transfondo_ID_Transfondo` (`ID_Transfondo`),
  ADD KEY `Enemigo_ID_Clase_Clase_ID_Clase` (`ID_Clase`),
  ADD KEY `Enemigo_ID_Subraza_Subraza_ID_Subraza` (`ID_Subraza`),
  ADD KEY `Enemigo_ID_Objeto_Objeto_ID_Objeto` (`ID_Objeto`);

--
-- Indices de la tabla `habilidades`
--
ALTER TABLE `habilidades`
  ADD PRIMARY KEY (`ID_Habilidades`);

--
-- Indices de la tabla `hechizo`
--
ALTER TABLE `hechizo`
  ADD PRIMARY KEY (`ID_Hechizo`),
  ADD KEY `Hechizo_ID_Nivel_Nivel_ID_Nivel` (`ID_Nivel`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`ID_Inventario`),
  ADD UNIQUE KEY `unique_jugador_objeto` (`ID_Jugador`,`ID_Objeto`),
  ADD KEY `Inventario_ID_Jugador_Jugador_ID_Jugador` (`ID_Jugador`),
  ADD KEY `Inventario_ID_Objeto_Objeto_ID_Objeto` (`ID_Objeto`);

--
-- Indices de la tabla `jugador`
--
ALTER TABLE `jugador`
  ADD PRIMARY KEY (`ID_Jugador`),
  ADD UNIQUE KEY `Contrasena` (`Contrasena`),
  ADD KEY `Jugador_ID_Alineamiento_Alineamiento_ID_Alineamiento` (`ID_Alineamiento`),
  ADD KEY `Jugador_ID_Nivel_Nivel_ID_Nivel` (`ID_Nivel`),
  ADD KEY `Jugador_ID_Clase_Clase_ID_Clase` (`ID_Clase`),
  ADD KEY `Jugador_ID_Transfondo_Transfondo_ID_Transfondo` (`ID_Transfondo`),
  ADD KEY `Jugador_ID_Subraza_Subraza_ID_Subraza` (`ID_Subraza`);

--
-- Indices de la tabla `mapa`
--
ALTER TABLE `mapa`
  ADD PRIMARY KEY (`ID_Mapa`);

--
-- Indices de la tabla `misiones`
--
ALTER TABLE `misiones`
  ADD PRIMARY KEY (`ID_Misiones`),
  ADD KEY `Misiones_ID_Objeto_Objeto_ID_Objeto` (`ID_Objeto`),
  ADD KEY `Misiones_ID_Mapa_Mapa_ID_Mapa` (`ID_Mapa`),
  ADD KEY `Misiones_ID_NPC_NPC_ID_NPC` (`ID_NPC`),
  ADD KEY `Misiones_ID_Enemigo_Enemigo_ID_Enemigo` (`ID_Enemigo`);

--
-- Indices de la tabla `nivel`
--
ALTER TABLE `nivel`
  ADD PRIMARY KEY (`ID_Nivel`);

--
-- Indices de la tabla `npc`
--
ALTER TABLE `npc`
  ADD PRIMARY KEY (`ID_NPC`);

--
-- Indices de la tabla `objeto`
--
ALTER TABLE `objeto`
  ADD PRIMARY KEY (`ID_Objeto`);

--
-- Indices de la tabla `raza`
--
ALTER TABLE `raza`
  ADD PRIMARY KEY (`ID_Raza`);

--
-- Indices de la tabla `subraza`
--
ALTER TABLE `subraza`
  ADD PRIMARY KEY (`ID_Subraza`),
  ADD KEY `Subraza_ID_Raza_Raza_ID_Raza` (`ID_Raza`);

--
-- Indices de la tabla `tienda`
--
ALTER TABLE `tienda`
  ADD PRIMARY KEY (`ID_Tienda`),
  ADD KEY `Tienda_ID_Mapa_Mapa_ID_Mapa` (`ID_Mapa`);

--
-- Indices de la tabla `transfondo`
--
ALTER TABLE `transfondo`
  ADD PRIMARY KEY (`ID_Transfondo`);

--
-- Indices de la tabla `trasfondo_habilidades`
--
ALTER TABLE `trasfondo_habilidades`
  ADD PRIMARY KEY (`ID_TH`),
  ADD KEY `TH_ID_Transfondo` (`ID_Transfondo`),
  ADD KEY `TH_ID_Habilidades` (`ID_Habilidades`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `jugador`
--
ALTER TABLE `jugador`
  MODIFY `ID_Jugador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clase_habilidades`
--
ALTER TABLE `clase_habilidades`
  ADD CONSTRAINT `ClHa_ID_Clase` FOREIGN KEY (`ID_Clase`) REFERENCES `clase` (`ID_Clase`),
  ADD CONSTRAINT `ClHa_ID_Habilidad` FOREIGN KEY (`ID_Habilidad`) REFERENCES `habilidades` (`ID_Habilidades`);

--
-- Filtros para la tabla `conjuros`
--
ALTER TABLE `conjuros`
  ADD CONSTRAINT `Conjuros_ID_Clase_Clase_ID_Clase` FOREIGN KEY (`ID_Clase`) REFERENCES `clase` (`ID_Clase`),
  ADD CONSTRAINT `Conjuros_ID_Hechizo_Hechizo_ID_Hechizo` FOREIGN KEY (`ID_Hechizo`) REFERENCES `hechizo` (`ID_Hechizo`);

--
-- Filtros para la tabla `dialogonpc`
--
ALTER TABLE `dialogonpc`
  ADD CONSTRAINT `DialogoNPC_ID_NPC_NPC_ID_NPC` FOREIGN KEY (`ID_NPC`) REFERENCES `npc` (`ID_NPC`);

--
-- Filtros para la tabla `enemigo`
--
ALTER TABLE `enemigo`
  ADD CONSTRAINT `Enemigo_ID_Clase_Clase_ID_Clase` FOREIGN KEY (`ID_Clase`) REFERENCES `clase` (`ID_Clase`),
  ADD CONSTRAINT `Enemigo_ID_Objeto_Objeto_ID_Objeto` FOREIGN KEY (`ID_Objeto`) REFERENCES `objeto` (`ID_Objeto`),
  ADD CONSTRAINT `Enemigo_ID_Subraza_Subraza_ID_Subraza` FOREIGN KEY (`ID_Subraza`) REFERENCES `subraza` (`ID_Subraza`),
  ADD CONSTRAINT `Enemigo_ID_Transfondo_Transfondo_ID_Transfondo` FOREIGN KEY (`ID_Transfondo`) REFERENCES `transfondo` (`ID_Transfondo`),
  ADD CONSTRAINT `Enemigo_Nivel_Nivel_ID_Nivel` FOREIGN KEY (`Nivel`) REFERENCES `nivel` (`ID_Nivel`);

--
-- Filtros para la tabla `hechizo`
--
ALTER TABLE `hechizo`
  ADD CONSTRAINT `Hechizo_ID_Nivel_Nivel_ID_Nivel` FOREIGN KEY (`ID_Nivel`) REFERENCES `nivel` (`ID_Nivel`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `Inventario_ID_Objeto_Objeto_ID_Objeto` FOREIGN KEY (`ID_Objeto`) REFERENCES `objeto` (`ID_Objeto`);

--
-- Filtros para la tabla `jugador`
--
ALTER TABLE `jugador`
  ADD CONSTRAINT `Jugador_ID_Alineamiento_Alineamiento_ID_Alineamiento` FOREIGN KEY (`ID_Alineamiento`) REFERENCES `alineamiento` (`ID_Alineamiento`),
  ADD CONSTRAINT `Jugador_ID_Clase_Clase_ID_Clase` FOREIGN KEY (`ID_Clase`) REFERENCES `clase` (`ID_Clase`),
  ADD CONSTRAINT `Jugador_ID_Nivel_Nivel_ID_Nivel` FOREIGN KEY (`ID_Nivel`) REFERENCES `nivel` (`ID_Nivel`),
  ADD CONSTRAINT `Jugador_ID_Subraza_Subraza_ID_Subraza` FOREIGN KEY (`ID_Subraza`) REFERENCES `subraza` (`ID_Subraza`),
  ADD CONSTRAINT `Jugador_ID_Transfondo_Transfondo_ID_Transfondo` FOREIGN KEY (`ID_Transfondo`) REFERENCES `transfondo` (`ID_Transfondo`);

--
-- Filtros para la tabla `misiones`
--
ALTER TABLE `misiones`
  ADD CONSTRAINT `Misiones_ID_Enemigo_Enemigo_ID_Enemigo` FOREIGN KEY (`ID_Enemigo`) REFERENCES `enemigo` (`ID_Enemigo`),
  ADD CONSTRAINT `Misiones_ID_Mapa_Mapa_ID_Mapa` FOREIGN KEY (`ID_Mapa`) REFERENCES `mapa` (`ID_Mapa`),
  ADD CONSTRAINT `Misiones_ID_NPC_NPC_ID_NPC` FOREIGN KEY (`ID_NPC`) REFERENCES `npc` (`ID_NPC`),
  ADD CONSTRAINT `Misiones_ID_Objeto_Objeto_ID_Objeto` FOREIGN KEY (`ID_Objeto`) REFERENCES `objeto` (`ID_Objeto`);

--
-- Filtros para la tabla `subraza`
--
ALTER TABLE `subraza`
  ADD CONSTRAINT `Subraza_ID_Raza_Raza_ID_Raza` FOREIGN KEY (`ID_Raza`) REFERENCES `raza` (`ID_Raza`);

--
-- Filtros para la tabla `tienda`
--
ALTER TABLE `tienda`
  ADD CONSTRAINT `Tienda_ID_Mapa_Mapa_ID_Mapa` FOREIGN KEY (`ID_Mapa`) REFERENCES `mapa` (`ID_Mapa`);

--
-- Filtros para la tabla `trasfondo_habilidades`
--
ALTER TABLE `trasfondo_habilidades`
  ADD CONSTRAINT `TH_ID_Habilidades` FOREIGN KEY (`ID_Habilidades`) REFERENCES `habilidades` (`ID_Habilidades`),
  ADD CONSTRAINT `TH_ID_Transfondo` FOREIGN KEY (`ID_Transfondo`) REFERENCES `transfondo` (`ID_Transfondo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
