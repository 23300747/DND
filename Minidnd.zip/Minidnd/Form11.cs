﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace Proyecto_Dnd
{
    public partial class Form11 : Form
    {
        private int jugadorId;
        private int oroActual;
        private string categoriaActual = "Pocion";
        private ListView listaProductos;
        private Label lblOro;
        private Label lblDescripcion;
        private Button btnComprar;

        public Form11(int idJugador)
        {
            InitializeComponent();
            jugadorId = idJugador;
            ConfigurarTienda();
            CargarOroJugador();
            CargarProductos("Pocion");
        }

        private void ConfigurarTienda()
        {
            this.Text = "Tienda de Zark - Retiro del Dragón";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(40, 30, 20);

            Label lblTitulo = new Label
            {
                Text = "TIENDA DE ZARK",
                Font = new Font("Papyrus", 18, FontStyle.Bold),
                ForeColor = Color.Gold,
                AutoSize = false,
                Size = new Size(860, 50),
                Location = new Point(20, 10),
                TextAlign = ContentAlignment.MiddleCenter
            };

            lblOro = new Label
            {
                Text = "Oro: 0",
                Font = new Font("Papyrus", 12, FontStyle.Bold),
                ForeColor = Color.Gold,
                Location = new Point(720, 70),
                AutoSize = true
            };

            Button btnPociones = CrearBotonCategoria("POCIONES", 20, 70);
            Button btnArmas = CrearBotonCategoria("ARMAS", 180, 70);
            Button btnHechizos = CrearBotonCategoria("HECHIZOS", 340, 70);

            btnPociones.Click += (s, e) => CambiarCategoria("Pocion");
            btnArmas.Click += (s, e) => CambiarCategoria("Arma");
            btnHechizos.Click += (s, e) => CambiarCategoria("Hechizo");

            listaProductos = new ListView
            {
                Location = new Point(20, 120),
                Size = new Size(550, 360),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                BackColor = Color.FromArgb(240, 235, 220),
                Font = new Font("Segoe UI", 10)
            };
            listaProductos.Columns.Add("Producto", 300);
            listaProductos.Columns.Add("Precio", 120);
            listaProductos.Columns.Add("Stock", 100);
            listaProductos.SelectedIndexChanged += ListaProductos_SelectedIndexChanged;

            Panel panelInfo = new Panel
            {
                Location = new Point(590, 120),
                Size = new Size(290, 360),
                BackColor = Color.FromArgb(60, 45, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            Label lblTituloDesc = new Label
            {
                Text = "DESCRIPCIÓN",
                Font = new Font("Papyrus", 11, FontStyle.Bold),
                ForeColor = Color.Gold,
                Location = new Point(10, 10),
                AutoSize = true
            };

            lblDescripcion = new Label
            {
                Text = "Selecciona un producto para ver su descripción.",
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.White,
                Location = new Point(10, 45),
                Size = new Size(270, 260),
                AutoSize = false
            };

            btnComprar = new Button
            {
                Text = "COMPRAR",
                Location = new Point(10, 315),
                Size = new Size(270, 35),
                Font = new Font("Papyrus", 11, FontStyle.Bold),
                BackColor = Color.DarkGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnComprar.FlatAppearance.BorderColor = Color.Gold;
            btnComprar.Click += BtnComprar_Click;

            panelInfo.Controls.Add(lblTituloDesc);
            panelInfo.Controls.Add(lblDescripcion);
            panelInfo.Controls.Add(btnComprar);

            Button btnSalir = new Button
            {
                Text = "SALIR",
                Location = new Point(370, 500),
                Size = new Size(160, 45),
                Font = new Font("Papyrus", 12, FontStyle.Bold),
                BackColor = Color.DarkRed,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnSalir.FlatAppearance.BorderColor = Color.Gold;
            btnSalir.Click += (s, e) => this.Close();

            this.Controls.Add(lblTitulo);
            this.Controls.Add(lblOro);
            this.Controls.Add(btnPociones);
            this.Controls.Add(btnArmas);
            this.Controls.Add(btnHechizos);
            this.Controls.Add(listaProductos);
            this.Controls.Add(panelInfo);
            this.Controls.Add(btnSalir);
        }

        private Button CrearBotonCategoria(string texto, int x, int y)
        {
            Button btn = new Button
            {
                Text = texto,
                Location = new Point(x, y),
                Size = new Size(150, 35),
                Font = new Font("Papyrus", 10, FontStyle.Bold),
                BackColor = Color.SaddleBrown,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btn.FlatAppearance.BorderColor = Color.Gold;
            return btn;
        }

        private void CambiarCategoria(string categoria)
        {
            categoriaActual = categoria;
            CargarProductos(categoria);
        }

        private void CargarOroJugador()
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    string query = "SELECT Oro FROM jugador WHERE ID_Jugador = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        object resultado = cmd.ExecuteScalar();
                        oroActual = resultado != null ? Convert.ToInt32(resultado) : 0;
                        lblOro.Text = $"💰 {oroActual} ORO";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar oro: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarProductos(string categoria)
        {
            listaProductos.Items.Clear();
            btnComprar.Enabled = false;
            lblDescripcion.Text = "Selecciona un producto para ver su descripción.";

            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    string query = @"SELECT s.ID_Stock, o.ID_Objeto, o.Nombre, o.Precio, o.Categoria, o.Efecto, s.Cantidad, s.MultiplicadorPrecio
                                    FROM stock s
                                    INNER JOIN objeto o ON s.ID_Objeto = o.ID_Objeto
                                    WHERE o.Categoria = @cat AND s.Cantidad > 0";

                    using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@cat", categoria);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int precioBase = reader.GetInt32("Precio");
                                float multiplicador = reader.GetFloat("MultiplicadorPrecio");
                                int precioFinal = (int)(precioBase * multiplicador);
                                int cantidad = reader.GetInt32("Cantidad");
                                int efecto = reader.GetInt32("Efecto");

                                ListViewItem item = new ListViewItem(reader.GetString("Nombre"));
                                item.SubItems.Add($"{precioFinal} oro");
                                item.SubItems.Add(cantidad.ToString());

                                // Guardar datos en Tag
                                item.Tag = new
                                {
                                    IdObjeto = reader.GetInt32("ID_Objeto"),
                                    Precio = precioFinal,
                                    Efecto = efecto,
                                    Categoria = reader.GetString("Categoria")
                                };

                                listaProductos.Items.Add(item);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar productos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ListaProductos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listaProductos.SelectedItems.Count > 0)
            {
                var item = listaProductos.SelectedItems[0];
                dynamic datos = item.Tag;

                string descripcion = $"Categoría: {datos.Categoria}\n\n";
                descripcion += $"Efecto: {datos.Efecto}\n\n";
                descripcion += $"Precio: {datos.Precio} oro";

                lblDescripcion.Text = descripcion;
                btnComprar.Enabled = true;
            }
        }

        private void BtnComprar_Click(object sender, EventArgs e)
        {
            if (listaProductos.SelectedItems.Count == 0) return;

            var item = listaProductos.SelectedItems[0];
            string nombre = item.SubItems[0].Text;
            dynamic datos = item.Tag;
            int precio = datos.Precio;

            if (oroActual < precio)
            {
                MessageBox.Show("No tienes suficiente oro.", "Compra rechazada", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show($"¿Comprar {nombre} por {precio} oro?", "Confirmar compra", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                RealizarCompra(datos.IdObjeto, nombre, precio);
            }
        }

        private void RealizarCompra(int idObjeto, string nombreProducto, int precio)
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();

                    // Actualizar oro del jugador
                    string updateOro = "UPDATE jugador SET Oro = Oro - @precio WHERE ID_Jugador = @id";
                    using (MySqlCommand cmd = new MySqlCommand(updateOro, conexion))
                    {
                        cmd.Parameters.AddWithValue("@precio", precio);
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        cmd.ExecuteNonQuery();
                    }

                    // Agregar al inventario (INSERT o UPDATE si ya existe)
                    string insertInventario = @"INSERT INTO inventario (ID_Jugador, ID_Objeto, Cantidad, Equipado, Carga_Actual, Carga_Maxima)
                                               VALUES (@id, @objeto, 1, 0, 0, 100)
                                               ON DUPLICATE KEY UPDATE Cantidad = Cantidad + 1";
                    using (MySqlCommand cmd = new MySqlCommand(insertInventario, conexion))
                    {
                        cmd.Parameters.AddWithValue("@id", jugadorId);
                        cmd.Parameters.AddWithValue("@objeto", idObjeto);
                        cmd.ExecuteNonQuery();
                    }

                    // Reducir stock
                    string updateStock = @"UPDATE stock 
                                          SET Cantidad = Cantidad - 1 
                                          WHERE ID_Objeto = @objeto AND Cantidad > 0";
                    using (MySqlCommand cmd = new MySqlCommand(updateStock, conexion))
                    {
                        cmd.Parameters.AddWithValue("@objeto", idObjeto);
                        cmd.ExecuteNonQuery();
                    }

                    oroActual -= precio;
                    lblOro.Text = $"💰 {oroActual} ORO";
                    MessageBox.Show($"¡Has comprado {nombreProducto}!", "Compra exitosa", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Recargar productos
                    CargarProductos(categoriaActual);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al realizar la compra: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form11_Load(object sender, EventArgs e)
        {
        }
    }
}