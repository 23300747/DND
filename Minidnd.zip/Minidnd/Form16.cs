﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Reflection;

namespace Proyecto_Dnd
{
    public partial class Form16 : Form
    {
        private int usuarioId = Form9.JugadorIdActual;
        private Jugador jugador;
        private Enemigo enemigoActual;
        private bool turnoJugador = true;
        private int turnoNumero = 1;
        private int danoTotalInfligido = 0;
        private int danoTotalRecibido = 0;

        private Label lblHPJugador;
        private Label lblHPEnemigo;
        private Label lblEstadoCombate;
        private Label lblTurno;
        private Panel zonaJugador;
        private Panel zonaEnemigo;
        private Button[] botonesAccion;

        private int idEnemigoBase;
        private Form formularioOrigen;

        public Form16(int idEnemigo, Form origen)
        {
            InitializeComponent();
            this.idEnemigoBase = idEnemigo;
            this.formularioOrigen = origen;
            ConfigurarPantallaCombate();
            CargarDatosJugador();
            CargarEnemigo(idEnemigo);
            IniciarCombate();
        }

        private void Form16_Load(object sender, EventArgs e)
        {
        }

        private void ConfigurarPantallaCombate()
        {
            this.Text = "Combate D&D";
            this.BackColor = Color.FromArgb(40, 40, 40);
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;

            zonaJugador = new Panel()
            {
                Size = new Size(180, 180),
                Location = new Point(150, this.ClientSize.Height - 350),
                BackColor = Color.FromArgb(100, 70, 90, 150),
                BorderStyle = BorderStyle.FixedSingle
            };

            zonaEnemigo = new Panel()
            {
                Size = new Size(180, 180),
                Location = new Point(this.ClientSize.Width - 330, 150),
                BackColor = Color.FromArgb(100, 150, 60, 60),
                BorderStyle = BorderStyle.FixedSingle
            };

            this.Controls.Add(zonaJugador);
            this.Controls.Add(zonaEnemigo);

            lblTurno = new Label()
            {
                Text = "Turno 1",
                ForeColor = Color.Gold,
                Font = new Font("Consolas", 16, FontStyle.Bold),
                AutoSize = false,
                Size = new Size(200, 40),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(this.ClientSize.Width / 2 - 100, 20),
                BackColor = Color.FromArgb(200, 30, 30, 30),
                BorderStyle = BorderStyle.FixedSingle
            };

            lblHPJugador = new Label()
            {
                Text = "HP: 100 / 100",
                ForeColor = Color.LimeGreen,
                Font = new Font("Consolas", 16, FontStyle.Bold),
                AutoSize = false,
                Size = new Size(250, 40),
                TextAlign = ContentAlignment.MiddleLeft,
                Location = new Point(150, this.ClientSize.Height - 380),
                BackColor = Color.FromArgb(220, 10, 10, 10),
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(10, 8, 0, 0)
            };

            lblHPEnemigo = new Label()
            {
                Text = "HP: 100 / 100",
                ForeColor = Color.Red,
                Font = new Font("Consolas", 16, FontStyle.Bold),
                AutoSize = false,
                Size = new Size(250, 40),
                TextAlign = ContentAlignment.MiddleRight,
                Location = new Point(this.ClientSize.Width - 400, 110),
                BackColor = Color.FromArgb(220, 10, 10, 10),
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(0, 8, 10, 0)
            };

            lblEstadoCombate = new Label()
            {
                Text = "¡Comienza el combate!",
                ForeColor = Color.White,
                Font = new Font("Consolas", 14, FontStyle.Bold),
                AutoSize = false,
                Size = new Size(800, 180),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point((this.ClientSize.Width - 800) / 2, this.ClientSize.Height + 300 / 1-90),
                BackColor = Color.FromArgb(220, 20, 20, 20),
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(10)
            };

            this.Controls.Add(lblTurno);
            this.Controls.Add(lblHPJugador);
            this.Controls.Add(lblHPEnemigo);
            this.Controls.Add(lblEstadoCombate);

            lblTurno.BringToFront();
            lblHPJugador.BringToFront();
            lblHPEnemigo.BringToFront();
            lblEstadoCombate.BringToFront();

            CrearBotonesCombate();
        }

        private void CargarDatosJugador()
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    using (MySqlCommand cmd = new MySqlCommand("CALL CargarJugadorParaCombate(@JugadorId)", conexion))
                    {
                        cmd.Parameters.AddWithValue("@JugadorId", usuarioId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int dadosGolpe = reader.GetInt32("DadosGolpe");
                                int nivel = reader.GetInt32("ID_Nivel");
                                int constitucion = reader.GetInt32("Constitucion");

                                jugador = new Jugador
                                {
                                    HP = reader.GetInt32("HP"),
                                    HPMaximo = dadosGolpe + (constitucion * nivel),
                                    Fuerza = reader.GetInt32("Fuerza"),
                                    Destreza = reader.GetInt32("Destreza"),
                                    Constitucion = constitucion,
                                    Inteligencia = reader.GetInt32("Inteligencia"),
                                    ClaseId = reader.GetInt32("ID_Clase"),
                                    Nombre = reader.GetString("Nombre"),
                                    Nivel = nivel
                                };
                            }
                        }
                    }
                }

                string rutaImagenJugador = "";
                switch (jugador.ClaseId)
                {
                    case 1: rutaImagenJugador = "guerrero.png"; break;
                    case 2: rutaImagenJugador = "mago.png"; break;
                    case 3: rutaImagenJugador = "paladin.png"; break;
                    case 4: rutaImagenJugador = "clerigo.png"; break;
                }

                Image imgJugador = CargarImagenDesdeRecursos(rutaImagenJugador);
                if (imgJugador != null)
                {
                    zonaJugador.BackgroundImage = imgJugador;
                    zonaJugador.BackgroundImageLayout = ImageLayout.Stretch;
                }

                ActualizarUIJugador();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar jugador: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CargarEnemigo(int idEnemigo)
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    using (MySqlCommand cmd = new MySqlCommand("CALL CargarEnemigoPorID(@IDEnemigo)", conexion))
                    {
                        cmd.Parameters.AddWithValue("@IDEnemigo", idEnemigo);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                enemigoActual = new Enemigo
                                {
                                    ID = reader.GetInt32("ID_Enemigo"),
                                    Nombre = reader.GetString("Nombre"),
                                    HP = reader.GetInt32("HP"),
                                    HPMaximo = reader.GetInt32("HP"),
                                    Fuerza = reader.GetInt32("Fuerza"),
                                    Destreza = reader.GetInt32("Destreza"),
                                    Constitucion = reader.GetInt32("Constitucion"),
                                    Inteligencia = reader.GetInt32("Inteligencia"),
                                    Nivel = reader.GetInt32("Nivel")
                                };
                            }
                        }
                    }
                }

                string imagenEnemigo = ObtenerImagenEnemigo(enemigoActual.Nombre);
                Image imgEnemigo = CargarImagenDesdeRecursos(imagenEnemigo);
                if (imgEnemigo != null)
                {
                    zonaEnemigo.BackgroundImage = imgEnemigo;
                    zonaEnemigo.BackgroundImageLayout = ImageLayout.Stretch;
                }

                ActualizarUIEnemigo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar enemigo: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string ObtenerImagenEnemigo(string nombreEnemigo)
        {
            if (nombreEnemigo.Contains("Zombi") || nombreEnemigo.Contains("Ahogado")) return "zombi.png";
            if (nombreEnemigo.Contains("Pulpo")) return "pulpo.png";
            if (nombreEnemigo.Contains("Hongo")) return "hongoB.png";
            if (nombreEnemigo.Contains("Estirge")) return "bicho.png";
            if (nombreEnemigo.Contains("Draco")) return "dragonhumo.png";
            if (nombreEnemigo.Contains("Kobold")) return "kobold.png";
            if (nombreEnemigo.Contains("Aidron")) return "aidron.png";
            if (nombreEnemigo.Contains("Chispa")) return "chispa.png";
            if (nombreEnemigo.Contains("Dragón Espiritual")) return "dragonespiritual.png";
            return "zombi.png";
        }

        private void IniciarCombate()
        {
            lblEstadoCombate.Text = $"⚔️ INICIO DE COMBATE ⚔️\n\n" +
                $"Te enfrentas a:\n{enemigoActual.Nombre}\n\n" +
                $"¡Prepárate para luchar!";
            lblEstadoCombate.ForeColor = Color.Yellow;
        }

        private void CrearBotonesCombate()
        {
            botonesAccion = new Button[5];

            botonesAccion[0] = CrearBoton("Atacar", BtnAtacar_Click);
            botonesAccion[1] = CrearBoton("Habilidad", BtnHabilidad_Click);
            botonesAccion[2] = CrearBoton("Defender", BtnDefender_Click);
            botonesAccion[3] = CrearBoton("Curar", BtnCurar_Click);
            botonesAccion[4] = CrearBoton("Huir", BtnHuir_Click);

            int espacio = 15;
            int anchoBoton = 110;
            int totalAncho = (anchoBoton * 5) + (espacio * 4);
            int xInicial = (this.ClientSize.Width - totalAncho) / 2;
            int yPos = this.ClientSize.Height - 100;

            for (int i = 0; i < botonesAccion.Length; i++)
            {
                botonesAccion[i].Location = new Point(xInicial + (i * (anchoBoton + espacio)), yPos);
                this.Controls.Add(botonesAccion[i]);
                botonesAccion[i].BringToFront();
            }
        }

        private Button CrearBoton(string texto, EventHandler clickHandler)
        {
            Button btn = new Button()
            {
                Text = texto,
                Size = new Size(110, 60),
                BackColor = Color.FromArgb(139, 69, 19),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Papyrus", 11, FontStyle.Bold)
            };

            btn.FlatAppearance.BorderColor = Color.Gold;
            btn.FlatAppearance.BorderSize = 2;
            btn.Click += clickHandler;

            btn.MouseEnter += (s, e) => btn.BackColor = Color.FromArgb(160, 82, 45);
            btn.MouseLeave += (s, e) => btn.BackColor = Color.FromArgb(139, 69, 19);

            return btn;
        }

        private void BtnAtacar_Click(object sender, EventArgs e)
        {
            if (!turnoJugador) return;

            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    using (MySqlCommand cmd = new MySqlCommand("CALL RealizarAtaqueConDados(@Atacante, @HPDefensor, @FuerzaAtacante, @DestrezaDefensor, @ConstitucionDefensor, @Dado, @DanoFinal, @HPRestante, @EsCritico, @Mensaje)", conexion))
                    {
                        cmd.Parameters.AddWithValue("@Atacante", jugador.Nombre);
                        cmd.Parameters.AddWithValue("@HPDefensor", enemigoActual.HP);
                        cmd.Parameters.AddWithValue("@FuerzaAtacante", jugador.Fuerza);
                        cmd.Parameters.AddWithValue("@DestrezaDefensor", enemigoActual.Destreza);
                        cmd.Parameters.AddWithValue("@ConstitucionDefensor", enemigoActual.Constitucion);

                        cmd.Parameters.Add("@Dado", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                        cmd.Parameters.Add("@DanoFinal", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                        cmd.Parameters.Add("@HPRestante", MySqlDbType.Int32).Direction = System.Data.ParameterDirection.Output;
                        cmd.Parameters.Add("@EsCritico", MySqlDbType.Bit).Direction = System.Data.ParameterDirection.Output;
                        cmd.Parameters.Add("@Mensaje", MySqlDbType.VarChar, 200).Direction = System.Data.ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        int dano = Convert.ToInt32(cmd.Parameters["@DanoFinal"].Value);
                        int hpRestante = Convert.ToInt32(cmd.Parameters["@HPRestante"].Value);
                        string mensaje = cmd.Parameters["@Mensaje"].Value.ToString();
                        bool critico = Convert.ToBoolean(cmd.Parameters["@EsCritico"].Value);
                        int dado = Convert.ToInt32(cmd.Parameters["@Dado"].Value);

                        enemigoActual.HP = hpRestante;
                        danoTotalInfligido += dano;

                        // Formatear mensaje de forma más clara
                        if (dano > 0)
                        {
                            if (critico)
                            {
                                lblEstadoCombate.Text = $"🎯 ¡GOLPE CRÍTICO! 🎯\n\n" +
                                    $"{jugador.Nombre} lanza un ataque devastador\n" +
                                    $"D20: {dado} (CRÍTICO)\n" +
                                    $"Daño: {dano} HP\n\n" +
                                    $"¡{enemigoActual.Nombre} recibe un golpe mortal!";
                                lblEstadoCombate.ForeColor = Color.Gold;
                            }
                            else
                            {
                                lblEstadoCombate.Text = $"⚔️ ATAQUE EXITOSO ⚔️\n\n" +
                                    $"{jugador.Nombre} golpea a {enemigoActual.Nombre}\n" +
                                    $"D20: {dado}\n" +
                                    $"Daño: {dano} HP\n\n" +
                                    $"HP Enemigo: {enemigoActual.HP}/{enemigoActual.HPMaximo}";
                                lblEstadoCombate.ForeColor = Color.LightGreen;
                            }
                        }
                        else
                        {
                            lblEstadoCombate.Text = $"❌ ATAQUE FALLIDO ❌\n\n" +
                                $"{jugador.Nombre} intenta golpear\n" +
                                $"D20: {dado}\n\n" +
                                $"¡{enemigoActual.Nombre} esquiva el ataque!";
                            lblEstadoCombate.ForeColor = Color.Orange;
                        }

                        ActualizarUIEnemigo();
                    }
                }

                System.Threading.Thread.Sleep(1500);

                if (!VerificarFinCombate())
                {
                    TurnoEnemigo();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en ataque: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnHabilidad_Click(object sender, EventArgs e)
        {
            if (!turnoJugador) return;
            MessageBox.Show("Sistema de habilidades en desarrollo\n(Se implementará con las habilidades de cada clase)", "Habilidad", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDefender_Click(object sender, EventArgs e)
        {
            if (!turnoJugador) return;

            lblEstadoCombate.Text = $"🛡️ POSICIÓN DEFENSIVA 🛡️\n\n" +
                $"{jugador.Nombre} se prepara para el ataque\n\n" +
                $"Bonus: +5 Constitución\n" +
                $"Este turno recibirás menos daño";
            lblEstadoCombate.ForeColor = Color.Cyan;

            jugador.Constitucion += 5;

            System.Threading.Thread.Sleep(1500);
            TurnoEnemigo();

            jugador.Constitucion -= 5;
        }

        private void BtnCurar_Click(object sender, EventArgs e)
        {
            if (!turnoJugador) return;

            int dadoCuracion = TirarDado(8);
            int bonusCON = jugador.Constitucion;
            int curacionTotal = dadoCuracion + bonusCON;
            int hpAntes = jugador.HP;
            jugador.HP = Math.Min(jugador.HP + curacionTotal, jugador.HPMaximo);
            int curacionReal = jugador.HP - hpAntes;

            lblEstadoCombate.Text = $"💚 CURACIÓN 💚\n\n" +
                $"{jugador.Nombre} se cura\n" +
                $"D8: {dadoCuracion} + CON: {bonusCON}\n\n" +
                $"HP Restaurado: {curacionReal}\n" +
                $"HP Actual: {jugador.HP}/{jugador.HPMaximo}";
            lblEstadoCombate.ForeColor = Color.LightGreen;

            ActualizarUIJugador();

            System.Threading.Thread.Sleep(1500);
            TurnoEnemigo();
        }

        private void BtnHuir_Click(object sender, EventArgs e)
        {
            int dado = TirarDado(20);
            int total = dado + jugador.Destreza;

            if (total >= 15)
            {
                lblEstadoCombate.Text = $"💨 HUIDA EXITOSA 💨\n\n" +
                    $"D20: {dado} + DES: {jugador.Destreza} = {total}\n\n" +
                    $"¡Logras escapar del combate!";
                lblEstadoCombate.ForeColor = Color.Yellow;

                System.Threading.Thread.Sleep(1500);
                GuardarProgreso();
                this.Close();
                formularioOrigen?.Show();
            }
            else
            {
                lblEstadoCombate.Text = $"❌ NO PUEDES HUIR ❌\n\n" +
                    $"D20: {dado} + DES: {jugador.Destreza} = {total}\n" +
                    $"Necesitas 15 o más\n\n" +
                    $"¡{enemigoActual.Nombre} te bloquea la salida!";
                lblEstadoCombate.ForeColor = Color.Red;

                System.Threading.Thread.Sleep(1500);
                TurnoEnemigo();
            }
        }

        private void TurnoEnemigo()
        {
            turnoJugador = false;
            BloquearBotones();

            System.Threading.Thread.Sleep(800);

            int dado = TirarDado(20);
            int ataqueEnemigo = dado + enemigoActual.Fuerza;
            int defensaJugador = 10 + jugador.Destreza;

            if (ataqueEnemigo >= defensaJugador)
            {
                int dadoDano = TirarDado(8);
                int dano = Math.Max(1, dadoDano + enemigoActual.Fuerza - jugador.Constitucion);
                jugador.HP -= dano;
                danoTotalRecibido += dano;

                lblEstadoCombate.Text = $"💀 ATAQUE ENEMIGO 💀\n\n" +
                    $"{enemigoActual.Nombre} te golpea\n" +
                    $"D20: {dado}\n" +
                    $"Daño: {dano} HP\n\n" +
                    $"Tu HP: {jugador.HP}/{jugador.HPMaximo}";
                lblEstadoCombate.ForeColor = Color.OrangeRed;

                ActualizarUIJugador();
            }
            else
            {
                lblEstadoCombate.Text = $"🎯 ESQUIVASTE 🎯\n\n" +
                    $"{enemigoActual.Nombre} intenta atacar\n" +
                    $"D20: {dado}\n\n" +
                    $"¡Logras esquivar el ataque!";
                lblEstadoCombate.ForeColor = Color.Cyan;
            }

            System.Threading.Thread.Sleep(2000);

            if (!VerificarFinCombate())
            {
                turnoNumero++;
                lblTurno.Text = $"Turno {turnoNumero}";
                turnoJugador = true;
                DesbloquearBotones();

                lblEstadoCombate.Text = $"⚔️ TU TURNO ⚔️\n\n" +
                    $"Elige tu acción";
                lblEstadoCombate.ForeColor = Color.White;
            }
        }

        private bool VerificarFinCombate()
        {
            if (enemigoActual.HP <= 0)
            {
                MessageBox.Show($"¡Has derrotado a {enemigoActual.Nombre}!\n\nTurnos: {turnoNumero}\nDaño infligido: {danoTotalInfligido}\nDaño recibido: {danoTotalRecibido}", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Information);
                OtorgarRecompensas();
                this.Close();
                formularioOrigen?.Show();
                return true;
            }
            else if (jugador.HP <= 0)
            {
                MessageBox.Show($"Has sido derrotado por {enemigoActual.Nombre}...\n\nTurnos sobrevividos: {turnoNumero}", "Derrota", MessageBoxButtons.OK, MessageBoxIcon.Error);
                jugador.HP = 1;
                GuardarProgreso();
                this.Close();
                formularioOrigen?.Show();
                return true;
            }
            return false;
        }

        private void OtorgarRecompensas()
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    using (MySqlCommand cmd = new MySqlCommand("CALL OtorgarRecompensasCombate(@JugadorId, @NivelEnemigo, @NombreEnemigo, @Turnos, @DanoInfligido, @DanoRecibido)", conexion))
                    {
                        cmd.Parameters.AddWithValue("@JugadorId", usuarioId);
                        cmd.Parameters.AddWithValue("@NivelEnemigo", enemigoActual.Nivel);
                        cmd.Parameters.AddWithValue("@NombreEnemigo", enemigoActual.Nombre);
                        cmd.Parameters.AddWithValue("@Turnos", turnoNumero);
                        cmd.Parameters.AddWithValue("@DanoInfligido", danoTotalInfligido);
                        cmd.Parameters.AddWithValue("@DanoRecibido", danoTotalRecibido);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int exp = reader.GetInt32("EXPGanada");
                                int oro = reader.GetInt32("OroGanado");
                                MessageBox.Show($"Recompensas obtenidas:\n+{exp} EXP\n+{oro} Oro", "Recompensas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                GuardarProgreso();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al otorgar recompensas: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void GuardarProgreso()
        {
            try
            {
                using (MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;"))
                {
                    conexion.Open();
                    string query = "UPDATE jugador SET HP = @hp WHERE ID_Jugador = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                    {
                        cmd.Parameters.AddWithValue("@hp", jugador.HP);
                        cmd.Parameters.AddWithValue("@id", usuarioId);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int TirarDado(int caras)
        {
            Random rnd = new Random();
            System.Threading.Thread.Sleep(10);
            return rnd.Next(1, caras + 1);
        }

        private void BloquearBotones()
        {
            foreach (var btn in botonesAccion)
                btn.Enabled = false;
        }

        private void DesbloquearBotones()
        {
            foreach (var btn in botonesAccion)
                btn.Enabled = true;
        }

        private void ActualizarUIJugador()
        {
            lblHPJugador.Text = $"HP: {jugador.HP} / {jugador.HPMaximo}";

            float porcentaje = (float)jugador.HP / jugador.HPMaximo;
            if (porcentaje > 0.6f)
                lblHPJugador.ForeColor = Color.LimeGreen;
            else if (porcentaje > 0.3f)
                lblHPJugador.ForeColor = Color.Yellow;
            else
                lblHPJugador.ForeColor = Color.Red;
        }

        private void ActualizarUIEnemigo()
        {
            lblHPEnemigo.Text = $"HP: {enemigoActual.HP} / {enemigoActual.HPMaximo}";

            float porcentaje = (float)enemigoActual.HP / enemigoActual.HPMaximo;
            if (porcentaje > 0.6f)
                lblHPEnemigo.ForeColor = Color.Red;
            else if (porcentaje > 0.3f)
                lblHPEnemigo.ForeColor = Color.Orange;
            else
                lblHPEnemigo.ForeColor = Color.DarkRed;
        }

        private Image CargarImagenDesdeRecursos(string nombreImagen)
        {
            var ensamblado = Assembly.GetExecutingAssembly();
            var rutaCompleta = $"Proyecto_Dnd.Recursos.{nombreImagen}";

            try
            {
                using (Stream stream = ensamblado.GetManifestResourceStream(rutaCompleta))
                {
                    if (stream != null)
                        return Image.FromStream(stream);
                }
            }
            catch { }
            return null;
        }

        public class Jugador
        {
            public string Nombre { get; set; }
            public int HP { get; set; }
            public int HPMaximo { get; set; }
            public int Fuerza { get; set; }
            public int Destreza { get; set; }
            public int Constitucion { get; set; }
            public int Inteligencia { get; set; }
            public int ClaseId { get; set; }
            public int Nivel { get; set; }
        }

        public class Enemigo
        {
            public int ID { get; set; }
            public string Nombre { get; set; }
            public int HP { get; set; }
            public int HPMaximo { get; set; }
            public int Fuerza { get; set; }
            public int Destreza { get; set; }
            public int Constitucion { get; set; }
            public int Inteligencia { get; set; }
            public int Nivel { get; set; }
        }
    }
}