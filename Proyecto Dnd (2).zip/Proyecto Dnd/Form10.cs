﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Proyecto_Dnd
{
    public partial class Form10 : Form
    {
        private PersonajeCompleto pj;

        public Form10(PersonajeCompleto personaje)
        {
            pj = personaje ?? new PersonajeCompleto();
            if (pj.EquipoActual == null)
                pj.EquipoActual = new Equipo();

            if (pj.Inventario == null)
                pj.Inventario = new System.Collections.Generic.List<Item>();
            if (pj.Inventario.Count == 0)
            {
                pj.Inventario.Add(new Item { Nombre = "Poción menor", Tipo = "Consumible", Descripcion = "Restaura 10 PV", BonVida = 10 });
                pj.Inventario.Add(new Item { Nombre = "Espada corta", Tipo = "Arma", Descripcion = "Arma básica +1 fuerza", BonFuerza = 1 });
            }

            InitializeComponent();

            // Asocia eventos aquí
            listaItems.SelectedIndexChanged += ListaItems_SelectedIndexChanged;
            btnEquipar.Click += BtnEquipar_Click;
            btnUsar.Click += BtnUsar_Click;
            btnCerrar.Click += (s, e) => this.Close();

            CargarDatosUI();
        }

        private void CargarDatosUI()
        {
            if (pj.ImagenPersonaje != null)
                pbImagen.Image = pj.ImagenPersonaje;
            else
            {
                Bitmap bmp = new Bitmap(pbImagen.Width, pbImagen.Height);
                using (var g = Graphics.FromImage(bmp))
                {
                    g.Clear(Color.DimGray);
                    using (var f = new Font("Segoe UI", 18, FontStyle.Bold))
                    using (var br = new SolidBrush(Color.White))
                    {
                        g.DrawString("SIN\nIMAGEN", f, br, new PointF(10, 60));
                    }
                }
                pbImagen.Image = bmp;
            }

            lblDatos.Text =
                $"Nombre: {pj.Nombre ?? "?"}\nClase: {pj.Clase ?? "?"}\nNivel: {pj.Nivel}\n\n" +
                $"STR: {pj.Fuerza}\nDEX: {pj.Destreza}\nCON: {pj.Constitucion}\nINT: {pj.Inteligencia}\n" +
                $"WIS: {pj.Sabiduria}\nCHA: {pj.Carisma}\n\nVida: {pj.VidaActual}/{pj.VidaMax}";

            listaItems.Items.Clear();
            if (pj.Inventario != null)
            {
                foreach (var it in pj.Inventario)
                {
                    var itv = new ListViewItem(it.Nombre ?? "Sin nombre");
                    itv.SubItems.Add(it.Tipo ?? "Sin tipo");
                    itv.SubItems.Add(it.Descripcion ?? "");
                    listaItems.Items.Add(itv);
                }
            }
        }

        private void ListaItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Puedes mostrar detalles si lo deseas
        }

        private void BtnEquipar_Click(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecciona un objeto.");
                return;
            }
            string nombre = listaItems.SelectedItems[0].Text;
            var item = pj.Inventario?.FirstOrDefault(i => i.Nombre == nombre);
            if (item == null) return;

            if (item.Tipo == "Arma") pj.EquipoActual.Arma = item;
            else if (item.Tipo == "Armadura") pj.EquipoActual.Armadura = item;
            else if (item.Tipo == "Accesorio") pj.EquipoActual.Accesorio = item;
            else
            {
                MessageBox.Show("No se puede equipar este objeto.");
                return;
            }

            CargarDatosUI();
            MessageBox.Show($"{item.Nombre} equipado.", "Equipar", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnUsar_Click(object sender, EventArgs e)
        {
            if (listaItems.SelectedItems.Count == 0)
            {
                MessageBox.Show("Selecciona un objeto.");
                return;
            }
            string nombre = listaItems.SelectedItems[0].Text;
            var item = pj.Inventario?.FirstOrDefault(i => i.Nombre == nombre);
            if (item == null) return;

            if (item.Tipo == "Consumible")
            {
                pj.VidaActual += item.BonVida;
                if (pj.VidaActual > pj.VidaMax) pj.VidaActual = pj.VidaMax;
                pj.Inventario.Remove(item);
                CargarDatosUI();
                MessageBox.Show($"Has usado {item.Nombre}.", "Usar", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ese objeto no es consumible.", "Usar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        public class Item
        {
            public string Nombre { get; set; }
            public string Tipo { get; set; }
            public string Descripcion { get; set; }
            public int BonVida { get; set; }
            public int BonFuerza { get; set; }
        }
        public class Equipo
        {
            public Item Arma { get; set; }
            public Item Armadura { get; set; }
            public Item Accesorio { get; set; }
        }
        public class PersonajeCompleto
        {
            public string Nombre { get; set; } = "Sin nombre";
            public string Clase { get; set; } = "Aventurero";
            public int Nivel { get; set; } = 1;
            public int Fuerza { get; set; } = 10;
            public int Destreza { get; set; } = 10;
            public int Constitucion { get; set; } = 10;
            public int Inteligencia { get; set; } = 10;
            public int Sabiduria { get; set; } = 10;
            public int Carisma { get; set; } = 10;
            public int VidaActual { get; set; } = 10;
            public int VidaMax { get; set; } = 10;
            public Equipo EquipoActual { get; set; } = new Equipo();
            public List<Item> Inventario { get; set; } = new List<Item>();
            public Image ImagenPersonaje { get; set; }
        }
    }
}
