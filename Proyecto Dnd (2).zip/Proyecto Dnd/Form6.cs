﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static Proyecto_Dnd.Form5;
using static Proyecto_Dnd.Form10;

namespace Proyecto_Dnd
{
    public partial class Form6 : Form
    {
        private Panel mapaCuevas;
        private const int tileSize = 50;
        private const int filas = 12;
        private const int columnas = 20;
        private Tile[,] mapa = new Tile[filas, columnas];
        private Personaje jugador;
        private int usuarioId = 18; // ID del jugador (cambia según el jugador logueado)

        public Form6()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.KeyPreview = true;
            this.Activated += (s, e) => this.Focus();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            mapaCuevas = new Panel
            {
                AutoScroll = true,
                Size = this.ClientSize,
                Location = new Point(0, 0)
            };
            this.Controls.Add(mapaCuevas);
            Mapa();
            CrearPersonaje();

            // Botón de inventario
            Button btnInventario = new Button();
            btnInventario.Text = "Inventario";
            btnInventario.Size = new Size(160, 40);
            btnInventario.Location = new Point(10, 10);
            btnInventario.BackColor = Color.SaddleBrown;
            btnInventario.ForeColor = Color.White;
            btnInventario.Font = new Font("Papyrus", 11, FontStyle.Bold);
            btnInventario.Click += (s, e2) =>
            {
                PersonajeCompleto personaje = CargarPersonajeDesdeDB(usuarioId);

                if (personaje != null)
                {
                    Form10 inventario = new Form10(personaje);
                    inventario.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No se pudo cargar el personaje.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            this.Controls.Add(btnInventario);
            btnInventario.BringToFront();
        }

        private Form10.PersonajeCompleto CargarPersonajeDesdeDB(int jugadorId)
        {
            Form10.PersonajeCompleto personaje = null;

            try
            {
                MessageBox.Show($"Intentando cargar jugador ID: {jugadorId}", "Debug");

                MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;");
                conexion.Open();

                MessageBox.Show("Conexión exitosa a la base de datos", "Debug");

                string query = @"SELECT j.ID_Jugador, j.Nombre, j.HP, j.Fuerza, j.Destreza, 
                                       j.Constitucion, j.Inteligencia, j.Sabiduria, j.Carisma, 
                                       j.ID_Nivel, j.ID_Clase, j.ID_Subraza,
                                       c.Nombre as NombreClase, s.Nombre as NombreRaza
                                FROM jugador j
                                LEFT JOIN clase c ON j.ID_Clase = c.ID_Clase
                                LEFT JOIN subraza s ON j.ID_Subraza = s.ID_Subraza
                                WHERE j.ID_Jugador = @JugadorId";

                using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@JugadorId", jugadorId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            MessageBox.Show("Jugador encontrado en la base de datos", "Debug");

                            personaje = new Form10.PersonajeCompleto
                            {
                                Nombre = reader.GetString("Nombre"),
                                Clase = reader.IsDBNull(reader.GetOrdinal("NombreClase")) ? "Sin clase" : reader.GetString("NombreClase"),
                                Nivel = reader.GetInt32("ID_Nivel"),
                                Fuerza = reader.GetInt32("Fuerza"),
                                Destreza = reader.GetInt32("Destreza"),
                                Constitucion = reader.GetInt32("Constitucion"),
                                Inteligencia = reader.GetInt32("Inteligencia"),
                                Sabiduria = reader.GetInt32("Sabiduria"),
                                Carisma = reader.GetInt32("Carisma"),
                                VidaActual = reader.GetInt32("HP"),
                                VidaMax = reader.GetInt32("HP"),
                                Inventario = new System.Collections.Generic.List<Form10.Item>(),
                                EquipoActual = new Form10.Equipo()
                            };

                            MessageBox.Show($"Personaje cargado: {personaje.Nombre}", "Debug");
                        }
                        else
                        {
                            MessageBox.Show($"No se encontró ningún jugador con ID: {jugadorId}", "Advertencia");
                        }
                    }
                }
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar personaje:\n\n{ex.Message}\n\nStackTrace:\n{ex.StackTrace}", "Error Detallado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return personaje;
        }

        private void Mapa()
        {
            for (int y = 0; y < filas; y++)
            {
                for (int x = 0; x < columnas; x++)
                {
                    Panel panel = new Panel
                    {
                        Size = new Size(tileSize, tileSize),
                        Location = new Point(x * tileSize, y * tileSize),
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = Color.DarkGray
                    };

                    mapaCuevas.Controls.Add(panel);

                    mapa[y, x] = new Tile
                    {
                        X = x,
                        Y = y,
                        PanelVisual = panel,
                        EsZona = false,
                        EsObstaculo = false,
                        Nombre = $"Cueva {x},{y}"
                    };
                }
            }
            SetZona(0, 10, Color.LightBlue, "Zona B1 – Túnel de entrada");
            SetZona(2, 10, Color.MediumSeaGreen, "Zona B2 – Granja de hongos");
            SetZona(4, 8, Color.Orange, "Zona B3 – Despensa");
            SetZona(6, 10, Color.Purple, "Zona B4 – Cámara circular");
            SetZona(8, 12, Color.Red, "Zona B5 – Santuario de Sinensa");
            SetZona(10, 18, Color.DarkSlateGray, "Zona B6 – Cueva del cristal");
            int[][] muros = new int[][]
            {
    new int[] {0,0}, new int[] {0,1}, new int[] {0,2}, new int[] {0,3}, new int[] {0,4},
    new int[] {0,5}, new int[] {0,6}, new int[] {0,7}, new int[] {0,8}, new int[] {0,9},
    new int[] {0,12}, new int[] {0,13}, new int[] {0,14},
    new int[] {0,15}, new int[] {0,16}, new int[] {0,17}, new int[] {0,18}, new int[] {0,19},
    new int[] {11,0}, new int[] {11,1}, new int[] {11,2}, new int[] {11,3}, new int[] {11,4},
    new int[] {11,5}, new int[] {11,6}, new int[] {11,7}, new int[] {11,8}, new int[] {11,9},
    new int[] {11,10}, new int[] {11,11}, new int[] {11,12}, new int[] {11,13}, new int[] {11,14},
    new int[] {11,15}, new int[] {11,16}, new int[] {11,17}, new int[] {11,18}, new int[] {11,19},
    new int[] {1,0}, new int[] {2,0}, new int[] {3,0}, new int[] {4,0}, new int[] {5,0},
    new int[] {6,0}, new int[] {7,0}, new int[] {8,0}, new int[] {9,0}, new int[] {10,0},
    new int[] {1,19}, new int[] {2,19}, new int[] {3,19}, new int[] {4,19}, new int[] {5,19},
    new int[] {6,19}, new int[] {7,19}, new int[] {8,19}, new int[] {9,19}, new int[] {10,19},
    new int[] {8,1}, new int[] {8,2}, new int[] {8,3}, new int[] {8,4},
    new int[] {10,1}, new int[] {10,2}, new int[] {10,3}, new int[] {10,4}, new int[] {10,5}, new int[] {10,6},
    new int[] {2,2}, new int[] {3,2}, new int[] {4,2}, new int[] {5,2}, new int[] {6,2},
    new int[] {2,4}, new int[] {3,4}, new int[] {4,4}, new int[] {5,4}, new int[] {6,4}, new int[] {7,4},
    new int[] {4,9}, new int[] {4,10}, new int[] {4,11},
    new int[] {6,8}, new int[] {7,8},
    new int[] {5,12}, new int[] {7,12},
    new int[] {2,7},
    new int[] {6,7}, new int[] {6,9},
    new int[] {3,6}, new int[] {5,6},
    new int[] {3,10}, new int[] {4,10}, new int[] {5,10},
    new int[] {4,13}, new int[] {4,14}, new int[] {4,15},
    new int[] {8,13}, new int[] {8,14}, new int[] {8,15},
    new int[] {5,11}, new int[] {6,11}, new int[] {7,11},
    new int[] {5,16},  new int[] {7,16},
    new int[] {7,12}, new int[] {7,13}, new int[] {7,14}, new int[] {7,15},
    new int[] {11,12}, new int[] {11,13}, new int[] {11,14}, new int[] {11,15},
    new int[] {9,11}, new int[] {10,11},
    new int[] {7,16}, new int[] {7,17}, new int[] {7,18},
    new int[] {11,16}, new int[] {11,17},
    new int[] {8,17}, new int[] {10,17},
    new int[] {2,5}, new int[] {2,6}, new int[] {2,7},
    new int[] {4,1}, new int[] {5,1}, new int[] {6,1},
    new int[] {2,13}, new int[] {2,14}, new int[] {2,15},
    new int[] {9,8}, new int[] {10,8}, new int[] {10,9}
            };

            foreach (var pos in muros)
            {
                int y = pos[0], x = pos[1];
                mapa[y, x].EsObstaculo = true;
                mapa[y, x].Nombre = "Muro fúngico";
                mapa[y, x].PanelVisual.BackColor = Color.Black;
            }
            SetEnemigo(2, 9, "Estirge");
            SetEnemigo(4, 6, "Hongo violeta");
            SetEnemigo(6, 12, "Hongo violeta");
            SetEnemigo(8, 11, "Estirge");
            SetEnemigo(10, 18, "Draco de humo");
        }

        private void SetZona(int y, int x, Color color, string nombre)
        {
            var panel = mapa[y, x].PanelVisual;
            panel.BackColor = color;
            panel.Controls.Add(new Label
            {
                Text = nombre,
                Font = new Font("Segoe UI", 7),
                AutoSize = true,
                ForeColor = Color.White
            });

            mapa[y, x].EsZona = true;
            mapa[y, x].Nombre = nombre;
        }

        private void CrearPersonaje()
        {
            jugador = new Personaje
            {
                X = 1,
                Y = 9
            };

            Panel visual = new Panel
            {
                Size = new Size(tileSize, tileSize),
                Location = mapa[jugador.Y, jugador.X].PanelVisual.Location,
                BackColor = Color.Blue
            };

            jugador.Visual = visual;
            mapaCuevas.Controls.Add(visual);
            jugador.Visual.BringToFront();
        }

        public class Tile
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel PanelVisual { get; set; }
            public bool EsZona { get; set; }
            public bool EsObstaculo { get; set; }
            public string Nombre { get; set; }
        }

        public class Personaje
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel Visual { get; set; }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            int nuevoX = jugador.X;
            int nuevoY = jugador.Y;

            switch (keyData)
            {
                case Keys.W: nuevoY--; break;
                case Keys.S: nuevoY++; break;
                case Keys.A: nuevoX--; break;
                case Keys.D: nuevoX++; break;
            }

            if (nuevoX >= 0 && nuevoX < columnas && nuevoY >= 0 && nuevoY < filas)
            {
                Tile destino = mapa[nuevoY, nuevoX];
                if (!destino.EsObstaculo)
                {
                    jugador.X = nuevoX;
                    jugador.Y = nuevoY;
                    jugador.Visual.Location = destino.PanelVisual.Location;
                    jugador.Visual.BringToFront();
                    jugador.Visual.Invalidate();
                    mapaCuevas.ScrollControlIntoView(jugador.Visual);

                    ActivarZona(destino);
                }
                if (jugador.X == 1 && jugador.Y == 9)
                {
                    MessageBox.Show("Regresando al Retiro del Dragón...", "Transición", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Form5 retiro = new Form5();
                    retiro.Show();
                    retiro.MoverJugadorA(0, 23);

                    this.Close();
                    return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void ActivarZona(Tile tile)
        {
            switch (tile.Nombre)
            {
                case "Zona B1 – Túnel de entrada":
                    MessageBox.Show("Un túnel bioluminiscente se extiende ante ti. Esporas flotan en el agua.", "Zona B1", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Un pulpo espora emerge del agua y ataca a los intrusos.", "Guardia fúngico", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;

                case "Zona B2 – Granja de hongos":
                    MessageBox.Show("Un bosque de hongos multicolores se extiende ante ti. Dos brotes micónidos trabajan junto al estanque.", "Zona B2", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Un hongo violeta cobra vida y extiende zarcillos morados hacia ti.", "¡Ataque fúngico!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;

                case "Zona B3 – Despensa":
                    MessageBox.Show("La cueva apesta a podredumbre. Tres brotes micónidos trabajan entre vegetación marchita.", "Zona B3", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Una estructura gelatinosa reluce en la pared... ¡Es un nido de estirges!", "Peligro aéreo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    break;

                case "Zona B4 – Cámara circular":
                    MessageBox.Show("Seis cúmulos de hongos gigantes forman un círculo. Micónidos en trance meditan en el centro.", "Zona B4", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Dos micónidos conscientes se acercan con actitud defensiva.", "Reacción hostil", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;

                case "Zona B5 – Santuario de Sinensa":
                    MessageBox.Show("Cristales brillantes y hongos rojos iluminan la cueva. En el centro, Sinensa yace inconsciente.", "Zona B5", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Los micónidos cuidan de su líder con esporas curativas. Defienden el santuario con vehemencia.", "Protección fúngica", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    break;

                case "Zona B6 – Cueva del cristal":
                    MessageBox.Show("El aire está impregnado de humo sulfúrico. Cristales morados y un núcleo naranja iluminan la cueva.", "Zona B6", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Dos dracos de humo emergen entre los gases y atacan a los intrusos.", "¡Combate elemental!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    MessageBox.Show("Si destruyes el cristal naranja, liberarás los gases y acabarás con la plaga.", "Cristal de fuego", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
            if (tile.Nombre.StartsWith("Zona B"))
            {
                MessageBox.Show($"Has entrado en {tile.Nombre}.", "Zona narrativa", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("¡Zona despejada! Has ganado.", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (tile.Nombre.StartsWith("Enemigo:"))
            {
                MessageBox.Show($"¡Te enfrentas a un {tile.Nombre.Replace("Enemigo: ", "")}!", "¡Combate!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                MessageBox.Show("¡Enemigo derrotado! Has ganado.", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            if (tile.EsZona)
            {
                tile.PanelVisual.BackColor = Color.DimGray;
                tile.PanelVisual.Controls.Clear();
                tile.Nombre = $"Cueva {tile.X},{tile.Y}";
                tile.EsZona = false;
            }
        }

        void SetEnemigo(int y, int x, string tipo)
        {
            var panel = mapa[y, x].PanelVisual;
            panel.BackColor = Color.IndianRed;
            panel.Controls.Add(new Label
            {
                Text = tipo,
                Font = new Font("Papyrus", 11, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true
            });

            mapa[y, x].EsZona = true;
            mapa[y, x].Nombre = $"Enemigo: {tipo}";
        }
    }
}