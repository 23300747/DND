﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Proyecto_Dnd
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
            this.Text = "Acceso a partida";
            this.Size = new Size(300, 200);

            Label lblUsuario = new Label() { Text = "Nombre:", Top = 20, Left = 20 };
            TextBox txtUsuario = new TextBox() { Name = "txtUsuario", Top = 40, Left = 20, Width = 240 };
            Label lblContrasena = new Label() { Text = "Contraseña:", Top = 70, Left = 20 };
            TextBox txtContrasena = new TextBox() { Name = "txtContrasena", Top = 90, Left = 20, Width = 240, PasswordChar = '*' };
            Button btnAcceder = new Button() { Text = "Acceder", Top = 130, Left = 20, Width = 240 };

            btnAcceder.Click += (s, e) =>
            {
                string nombre = txtUsuario.Text;
                string contrasena = txtContrasena.Text;

                if (ValidarCredenciales(nombre, contrasena))
                {
                    Form5 partida = new Form5();
                    partida.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos.");
                }
            };

            this.Controls.Add(lblUsuario);
            this.Controls.Add(txtUsuario);
            this.Controls.Add(lblContrasena);
            this.Controls.Add(txtContrasena);
            this.Controls.Add(btnAcceder);
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }
        private bool ValidarCredenciales(string nombre, string contrasena)
        {
            string cadenaConexion = "Server=localhost;Database=proyecto;Uid=root;Pwd=;";
            using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
            {
                using (MySqlCommand comando = new MySqlCommand("ValidarCredenciales", conexion))
                {
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.Parameters.AddWithValue("nombreJugador", nombre);
                    comando.Parameters.AddWithValue("contrasenaJugador", contrasena);

                    conexion.Open();
                    int resultado = Convert.ToInt32(comando.ExecuteScalar());
                    return resultado > 0;
                }
            }
        }
    }
}

