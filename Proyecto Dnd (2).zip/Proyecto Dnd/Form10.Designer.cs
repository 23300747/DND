﻿using System.Drawing;
using System.Windows.Forms;

namespace Proyecto_Dnd
{
    partial class Form10
    {
        private ListView listaItems;
        private Label lblDatos;
        private PictureBox pbImagen;
        private Button btnEquipar;
        private Button btnUsar;
        private Button btnCerrar;

        private void InitializeComponent()
        {
            this.pbImagen = new PictureBox();
            this.lblDatos = new Label();
            this.listaItems = new ListView();
            this.btnEquipar = new Button();
            this.btnUsar = new Button();
            this.btnCerrar = new Button();

            // Form
            this.SuspendLayout();
            this.ClientSize = new Size(900, 600);
            this.Text = "Form10 - Inventario";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.Black;

            // pbImagen
            this.pbImagen.Location = new Point(20, 20);
            this.pbImagen.Size = new Size(220, 220);
            this.pbImagen.SizeMode = PictureBoxSizeMode.StretchImage;
            this.pbImagen.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(this.pbImagen);

            // lblDatos
            this.lblDatos.Location = new Point(20, 250);
            this.lblDatos.Size = new Size(260, 300);
            this.lblDatos.ForeColor = Color.White;
            this.lblDatos.BackColor = Color.FromArgb(30, 30, 30);
            this.lblDatos.Font = new Font("Segoe UI", 9);
            this.lblDatos.AutoSize = false;
            this.Controls.Add(this.lblDatos);

            // listaItems
            this.listaItems.Location = new Point(300, 20);
            this.listaItems.Size = new Size(570, 460);
            this.listaItems.View = View.Details;
            this.listaItems.FullRowSelect = true;
            this.listaItems.GridLines = true;
            this.listaItems.Columns.Add("Objeto", 200);
            this.listaItems.Columns.Add("Tipo", 100);
            this.listaItems.Columns.Add("Descripción", 250);
            this.Controls.Add(this.listaItems);

            // btnEquipar
            this.btnEquipar.Text = "Equipar";
            this.btnEquipar.Location = new Point(300, 500);
            this.btnEquipar.Width = 120;
            this.btnEquipar.ForeColor = Color.White;
            this.btnEquipar.BackColor = Color.DimGray;
            this.btnEquipar.FlatStyle = FlatStyle.Flat;
            this.Controls.Add(this.btnEquipar);

            // btnUsar
            this.btnUsar.Text = "Usar";
            this.btnUsar.Location = new Point(440, 500);
            this.btnUsar.Width = 120;
            this.btnUsar.ForeColor = Color.White;
            this.btnUsar.BackColor = Color.DimGray;
            this.btnUsar.FlatStyle = FlatStyle.Flat;
            this.Controls.Add(this.btnUsar);

            // btnCerrar
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.Location = new Point(700, 500);
            this.btnCerrar.Width = 120;
            this.btnCerrar.ForeColor = Color.White;
            this.btnCerrar.BackColor = Color.DimGray;
            this.btnCerrar.FlatStyle = FlatStyle.Flat;
            this.Controls.Add(this.btnCerrar);

            this.ResumeLayout(false);
        }
    }
}
