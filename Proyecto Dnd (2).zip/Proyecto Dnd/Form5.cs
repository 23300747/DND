﻿using System;
using System.Reflection;
using MySql.Data.MySqlClient;
using System.Linq;
using static Proyecto_Dnd.Form10;

namespace Proyecto_Dnd
{
    public partial class Form5 : Form
    {
        private Dictionary<string, (int y, int x)> retiroDragon = new Dictionary<string, (int y, int x)>
        {
            { "Runara",  (10, 13) }, // templo
            { "Laylee",  (8, 13) }, // posada
            { "Zark",    (13,13 ) },   // tienda
            { "Tarak",   (13,8) },  // herrero
            { "Mila",    (8, 8) },   // informante
            { "Biblioteca",    (14, 10) }
        };

        public Form5()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        private int usuarioId = 18; // ID del jugador (cambia según el jugador logueado)

        private void Form5_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            MAP = new Panel();
            MAP.AutoScroll = true;
            MAP.Size = this.ClientSize;
            MAP.Location = new Point(0, 0);
            this.Controls.Add(MAP);

            Mapa();
            CrearPersonaje();

            // Botón de prueba para abrir el inventario
            Button btnInventario = new Button();
            btnInventario.Text = "Inventario (Prueba)";
            btnInventario.Size = new Size(160, 40);
            btnInventario.Location = new Point(10, 10);
            btnInventario.BackColor = Color.SaddleBrown;
            btnInventario.ForeColor = Color.White;
            btnInventario.Font = new Font("Papyrus", 11, FontStyle.Bold);
            btnInventario.Click += (s, e2) =>
            {
                PersonajeCompleto personaje = CargarPersonajeDesdeDB(usuarioId);

                if (personaje != null)
                {
                    Form10 inventario = new Form10(personaje);
                    inventario.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No se pudo cargar el personaje.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            this.Controls.Add(btnInventario);
            btnInventario.BringToFront();
        }

        private Form10.PersonajeCompleto CargarPersonajeDesdeDB(int jugadorId)
        {
            Form10.PersonajeCompleto personaje = null;

            try
            {
                MessageBox.Show($"Intentando cargar jugador ID: {jugadorId}", "Debug");

                MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;");
                conexion.Open();

                MessageBox.Show("Conexión exitosa a la base de datos", "Debug");

                string query = @"SELECT j.ID_Jugador, j.Nombre, j.HP, j.Fuerza, j.Destreza, 
                                       j.Constitucion, j.Inteligencia, j.Sabiduria, j.Carisma, 
                                       j.ID_Nivel, j.ID_Clase, j.ID_Subraza,
                                       c.Nombre as NombreClase, s.Nombre as NombreRaza
                                FROM jugador j
                                LEFT JOIN clase c ON j.ID_Clase = c.ID_Clase
                                LEFT JOIN subraza s ON j.ID_Subraza = s.ID_Subraza
                                WHERE j.ID_Jugador = @JugadorId";

                using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@JugadorId", jugadorId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            MessageBox.Show("Jugador encontrado en la base de datos", "Debug");

                            personaje = new Form10.PersonajeCompleto
                            {
                                Nombre = reader.GetString("Nombre"),
                                Clase = reader.IsDBNull(reader.GetOrdinal("NombreClase")) ? "Sin clase" : reader.GetString("NombreClase"),
                                Nivel = reader.GetInt32("ID_Nivel"),
                                Fuerza = reader.GetInt32("Fuerza"),
                                Destreza = reader.GetInt32("Destreza"),
                                Constitucion = reader.GetInt32("Constitucion"),
                                Inteligencia = reader.GetInt32("Inteligencia"),
                                Sabiduria = reader.GetInt32("Sabiduria"),
                                Carisma = reader.GetInt32("Carisma"),
                                VidaActual = reader.GetInt32("HP"),
                                VidaMax = reader.GetInt32("HP"),
                                Inventario = new System.Collections.Generic.List<Form10.Item>(),
                                EquipoActual = new Form10.Equipo()
                            };

                            MessageBox.Show($"Personaje cargado: {personaje.Nombre}", "Debug");
                        }
                        else
                        {
                            MessageBox.Show($"No se encontró ningún jugador con ID: {jugadorId}", "Advertencia");
                        }
                    }
                }
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar personaje:\n\n{ex.Message}\n\nStackTrace:\n{ex.StackTrace}", "Error Detallado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return personaje;
        }

        private const int Tamano = 50;
        private const int filas = 25;
        private const int columnas = 40;
        private Tile[,] mapa = new Tile[filas, columnas];
        private Personaje jugador;
        private Panel MAP;

        private void Mapa()
        {
            for (int y = 0; y < filas; y++)
            {
                for (int x = 0; x < columnas; x++)
                {
                    Panel tilePanel = new Panel();
                    tilePanel.Size = new Size(Tamano, Tamano);
                    tilePanel.Location = new Point(x * Tamano, y * Tamano);
                    tilePanel.BorderStyle = BorderStyle.FixedSingle;
                    MAP.Controls.Add(tilePanel);
                    SetFondo(tilePanel, "pasto.png");
                    mapa[y, x] = new Tile
                    {
                        X = x,
                        Y = y,
                        PanelVisual = tilePanel,
                        EsZona = false,
                        EsObstaculo = false,
                        Nombre = $"Tile {x},{y}"
                    };
                }
            }
            SetFondo(mapa[0, 0].PanelVisual, "arena.png");
            SetFondo(mapa[0, 1].PanelVisual, "arena.png");
            SetFondo(mapa[0, 2].PanelVisual, "arena.png");
            SetFondo(mapa[0, 3].PanelVisual, "arena.png");
            SetFondo(mapa[0, 4].PanelVisual, "arena.png");
            SetFondo(mapa[1, 0].PanelVisual, "arena.png");
            SetFondo(mapa[1, 1].PanelVisual, "arena.png");
            SetFondo(mapa[1, 2].PanelVisual, "arena.png");
            SetFondo(mapa[1, 3].PanelVisual, "arena.png");
            SetFondo(mapa[1, 4].PanelVisual, "arena.png");
            SetFondo(mapa[2, 0].PanelVisual, "arena.png");
            SetFondo(mapa[2, 1].PanelVisual, "arena.png");
            SetFondo(mapa[2, 2].PanelVisual, "arena.png");
            SetFondo(mapa[2, 3].PanelVisual, "arena.png");
            SetFondo(mapa[2, 4].PanelVisual, "arena.png");
            SetFondo(mapa[3, 0].PanelVisual, "arena.png");
            SetFondo(mapa[3, 1].PanelVisual, "arena.png");
            SetFondo(mapa[3, 2].PanelVisual, "arena.png");
            SetFondo(mapa[3, 3].PanelVisual, "arena.png");
            SetFondo(mapa[3, 4].PanelVisual, "arena.png");
            SetFondo(mapa[4, 0].PanelVisual, "arena.png");
            SetFondo(mapa[4, 1].PanelVisual, "arena.png");
            SetFondo(mapa[4, 2].PanelVisual, "arena.png");
            SetFondo(mapa[4, 3].PanelVisual, "arena.png");

            foreach (var kvp in retiroDragon)
            {
                var nombre = kvp.Key;
                var (y, x) = kvp.Value;
                var panel = mapa[y, x].PanelVisual;
                panel.BackgroundImage = null;
                panel.BackColor = Color.CadetBlue;
                panel.Font = new Font("Papyrus", 11);
                panel.BringToFront();
                mapa[y, x].EsZona = true;
                mapa[y, x].EsObstaculo = nombre != "Biblioteca";
                mapa[y, x].Nombre = nombre == "Biblioteca" ? "Biblioteca del Retiro" : $"Retiro del Dragón – {nombre}";
            }
            mapa[14, 10].EsObstaculo = false;
            mapa[14, 10].EsZona = true;
            mapa[14, 10].Nombre = "Biblioteca del Retiro";
            SetFondo(mapa[14, 10].PanelVisual, "casa.png");
            int[][] muros = new int[][]
            {
                new int[] {7,7}, new int[] {7,8}, new int[] {7,9}, new int[] {7,11}, new int[] {7,12},
                new int[] {7,13}, new int[] {7,14}, new int[] {14,7}, new int[] {14,8}, new int[] {14,9},
                new int[] {14,11}, new int[] {14,12}, new int[] {14,13}, new int[] {14,14}, new int[] {8,7},
                new int[] {9,7}, new int[] {11,7}, new int[] {12,7}, new int[] {13,7}, new int[] {14,7},
                new int[] {7,14}, new int[] {8,14}, new int[] {9,14}, new int[] {10,14}, new int[] {11,14},
                new int[] {12,14}, new int[] {13,14}, new int[] {14,14}
            };
            foreach (var pos in muros) { SetObstaculo(pos[0], pos[1]); }

            Setmontana(5, 0);
            Setmontana(5, 1);
            Setmontana(5, 2);
            Setmontana(5, 3);
            Setmontana(0, 5);
            Setmontana(1, 5);
            Setmontana(2, 5);
            Setmontana(3, 5);

            SetEnemigo(4, 4, "Zombi");
            SetEnemigo(8, 6, "Zombi");
            SetEnemigo(12, 6, "Zombi");
            SetEnemigo(13, 12, "Zombi");
            SetEnemigo(10, 6, "Zombi");
            SetEnemigo(0, 15, "Ahogado");
            SetEnemigo(0, 17, "Ahogado");
            SetEnemigo(2, 16, "Ahogado");
            SetEnemigo(20, 20, "Pulpo fúngico");
            SetEnemigo(3, 18, "Zombi");
            SetEnemigo(6, 25, "Zombi");
            SetEnemigo(9, 30, "Zombi");
            SetEnemigo(15, 5, "Ahogado");
            SetEnemigo(17, 12, "Ahogado");
            SetEnemigo(22, 35, "Ahogado");
            SetEnemigo(24, 10, "Zombi");
            SetEnemigo(19, 28, "Zombi");
            SetEnemigo(5, 23, "Zombi");

            mapa[21, 5].EsZona = true;
            mapa[21, 5].Nombre = "Aguas termales";
            mapa[18, 18].EsZona = true;
            mapa[18, 18].Nombre = "Territorio del oso lechuza";
            mapa[22, 10].EsZona = true;
            mapa[22, 10].Nombre = "Emboscada de kobolds";
        }

        private void SetObstaculo(int y, int x)
        {
            mapa[y, x].EsObstaculo = true;
            mapa[y, x].Nombre = "Muro bloqueado";
            SetFondo(mapa[y, x].PanelVisual, "casa.png");
        }

        private void Setmontana(int y, int x)
        {
            mapa[y, x].EsObstaculo = true;
            mapa[y, x].Nombre = "Muro bloqueado";
            SetFondo(mapa[y, x].PanelVisual, "montana.png");
        }

        private void SetEnemigo(int y, int x, string tipo)
        {
            var panel = mapa[y, x].PanelVisual;
            panel.BackgroundImage = null;
            panel.BackColor = Color.IndianRed;
            panel.BringToFront();

            mapa[y, x].EsZona = true;
            mapa[y, x].Nombre = $"Enemigo: {tipo}";
        }

        private void CrearPersonaje()
        {
            jugador = new Personaje();
            jugador.X = 2;
            jugador.Y = 2;
            Panel visual = new Panel();
            visual.Size = new Size(Tamano, Tamano);
            visual.Location = mapa[jugador.Y, jugador.X].PanelVisual.Location;
            visual.BackColor = Color.Transparent;
            visual.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.FillEllipse(Brushes.Blue, 5, 5, Tamano - 10, Tamano - 10);
            };
            jugador.Visual = visual;
            MAP.Controls.Add(visual);
            jugador.Visual.BringToFront();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            int nuevoX = jugador.X;
            int nuevoY = jugador.Y;
            switch (keyData)
            {
                case Keys.W: nuevoY--; break;
                case Keys.S: nuevoY++; break;
                case Keys.A: nuevoX--; break;
                case Keys.D: nuevoX++; break;
            }
            if (nuevoX >= 0 && nuevoX < columnas && nuevoY >= 0 && nuevoY < filas)
            {
                Tile destino = mapa[nuevoY, nuevoX];
                if (!destino.EsObstaculo)
                {
                    jugador.X = nuevoX;
                    jugador.Y = nuevoY;
                    jugador.Visual.Location = destino.PanelVisual.Location;
                    jugador.Visual.BringToFront();
                    jugador.Visual.Invalidate();

                    MAP.ScrollControlIntoView(jugador.Visual);

                    if (destino.EsZona)
                    {
                        MessageBox.Show($"Has entrado en: {destino.Nombre}", "Zona especial", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    if (jugador.X == 0 && jugador.Y == filas - 1)
                    {
                        MessageBox.Show("Una oscuridad sombria te rodea y te notas cansado", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Form6 Cap2 = new Form6();
                        Cap2.Show();
                        return true;
                    }
                    if (jugador.X == 0 && jugador.Y == 0)
                    {
                        MessageBox.Show("Una voz en tu cabeza dice que te subas al barco", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.Hide();
                        Form7 Cap3 = new Form7();
                        Cap3.Show();
                        return true;
                    }
                    if (jugador.X == 39 && jugador.Y == 12)
                    {
                        MessageBox.Show("Escuchas los resagos de antiguos guerreros", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Form8 Cap4 = new Form8();
                        Cap4.Show();
                        return true;
                    }
                }
            }
            if (jugador.X == 13 && jugador.Y == 10) // Templo de Runara
            {
                MessageBox.Show("Runara sonríe. \"Tengo algo que mostraros...\"", "Encuentro narrativo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MessageBox.Show("Un destello... aparece un dragón de escamas bronce. \"Ahora me veis con mi apariencia real.\"", "Runara revelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                MessageBox.Show("Runara les entrega una llave de piedra lunar para entrar al observatorio.", "Objeto clave obtenido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            var tileActual = mapa[jugador.Y, jugador.X];
            if (tileActual.Nombre.StartsWith("Enemigo:"))
            {
                tileActual.PanelVisual.BackColor = Color.DarkSlateGray;
                tileActual.Nombre = $"Tile {jugador.X},{jugador.Y}";
                tileActual.EsZona = false;

                MessageBox.Show("Has derrotado al enemigo en esta zona.", "Combate resuelto", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (keyData == Keys.E)
            {
                foreach (var kvp in retiroDragon)
                {
                    var (py, px) = kvp.Value;
                    if (Math.Abs(jugador.X - px) + Math.Abs(jugador.Y - py) == 1)
                    {
                        string nombre = kvp.Key;

                        if (nombre == "Mila")
                        {
                            MostrarCuadroMisiones();
                        }
                        else
                        {
                            MessageBox.Show($"Interacción con {nombre}", "Personaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void MostrarCuadroMisiones()
        {
            Form cuadro = new Form();
            cuadro.Text = "Misiones disponibles";
            cuadro.Size = new Size(400, 320);
            cuadro.StartPosition = FormStartPosition.CenterParent;
            cuadro.FormBorderStyle = FormBorderStyle.FixedDialog;
            cuadro.MaximizeBox = false;
            cuadro.MinimizeBox = false;
            var misiones = new[]
            {
                ("Cuevas Marinas", "Matar al pulpo fúngico"),
                ("Pecio del Rosa de los Vientos", "Enfrentar zombis marinos"),
                ("Reaparición de zombis", "Defender el Retiro del Dragón"),
                ("Este reino está en tus manos", "Explora la isla y protege su destino")
            };
            int y = 20;
            foreach (var (titulo, objetivo) in misiones)
            {
                Label lbl = new Label();
                lbl.Text = $"{titulo}\n→ {objetivo}";
                lbl.Location = new Point(20, y);
                lbl.Size = new Size(340, 40);
                lbl.Font = new Font("Segoe UI", 10);
                cuadro.Controls.Add(lbl);
                y += 50;
            }
            Button cerrar = new Button();
            cerrar.Text = "Cerrar";
            cerrar.Size = new Size(100, 30);
            cerrar.Location = new Point(140, y);
            cerrar.Click += (s, e) => cuadro.Close();
            cuadro.Controls.Add(cerrar);
            cuadro.ShowDialog();
        }

        private void SetFondo(Panel panel, string nombreImagen)
        {
            Image fondo = CargarImagenDesdeRecursos(nombreImagen);
            if (fondo != null)
            {
                panel.BackgroundImage = fondo;
                panel.BackgroundImageLayout = ImageLayout.Stretch;
            }
            else
            {
                panel.BackColor = Color.LightGray;
                if (!panel.Controls.OfType<Label>().Any(lbl => lbl.Text == "Sin imagen"))
                {
                    panel.Controls.Add(new Label { Text = "Sin imagen", AutoSize = true });
                }
            }
        }

        public void MoverJugadorA(int x, int y)
        {
            if (jugador != null && x >= 0 && x < columnas && y >= 0 && y < filas)
            {
                jugador.X = x;
                jugador.Y = y;
                jugador.Visual.Location = mapa[y, x].PanelVisual.Location;
                jugador.Visual.BringToFront();
                MAP.ScrollControlIntoView(jugador.Visual);
            }
        }

        public class Tile
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel PanelVisual { get; set; }
            public bool EsZona { get; set; }
            public bool EsObstaculo { get; set; }
            public string Nombre { get; set; }
        }

        public class Personaje
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel Visual { get; set; }
        }

        private Image CargarImagenDesdeRecursos(string nombreImagen)
        {
            var ensamblado = Assembly.GetExecutingAssembly();
            var rutaCompleta = $"Proyecto_Dnd.Recursos.{nombreImagen}";

            using Stream stream = ensamblado.GetManifestResourceStream(rutaCompleta);
            if (stream != null)
            {
                return Image.FromStream(stream);
            }
            else
            {
                throw new FileNotFoundException($"No se encontró el recurso incrustado: {rutaCompleta}");
            }
        }
    }
}