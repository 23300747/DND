﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static Proyecto_Dnd.Form10;

namespace Proyecto_Dnd
{
    public partial class Form7 : Form
    {
        private Panel mapaPecio;
        private const int tileSize = 50;
        private const int filas = 12;
        private const int columnas = 20;
        private Tile[,] mapa = new Tile[filas, columnas];
        private Personaje jugador;
        private int usuarioId = 18; // ID del jugador (cambia según el jugador logueado)

        public Form7()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.KeyPreview = true;
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            mapaPecio = new Panel
            {
                AutoScroll = true,
                Size = this.ClientSize,
                Location = new Point(0, 0)
            };
            this.Controls.Add(mapaPecio);
            Mapa();
            CrearPersonaje();
            MarcarObstaculosEjemplo(jugador.X, jugador.Y);

            // Botón de inventario
            Button btnInventario = new Button();
            btnInventario.Text = "Inventario";
            btnInventario.Size = new Size(160, 40);
            btnInventario.Location = new Point(10, 10);
            btnInventario.BackColor = Color.SaddleBrown;
            btnInventario.ForeColor = Color.White;
            btnInventario.Font = new Font("Papyrus", 11, FontStyle.Bold);
            btnInventario.Click += (s, e2) =>
            {
                PersonajeCompleto personaje = CargarPersonajeDesdeDB(usuarioId);

                if (personaje != null)
                {
                    Form10 inventario = new Form10(personaje);
                    inventario.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No se pudo cargar el personaje.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            this.Controls.Add(btnInventario);
            btnInventario.BringToFront();
        }

        private Form10.PersonajeCompleto CargarPersonajeDesdeDB(int jugadorId)
        {
            Form10.PersonajeCompleto personaje = null;

            try
            {
                MessageBox.Show($"Intentando cargar jugador ID: {jugadorId}", "Debug");

                MySqlConnection conexion = new MySqlConnection("Server=localhost;Database=proyecto;Uid=root;Pwd=;");
                conexion.Open();

                MessageBox.Show("Conexión exitosa a la base de datos", "Debug");

                string query = @"SELECT j.ID_Jugador, j.Nombre, j.HP, j.Fuerza, j.Destreza, 
                                       j.Constitucion, j.Inteligencia, j.Sabiduria, j.Carisma, 
                                       j.ID_Nivel, j.ID_Clase, j.ID_Subraza,
                                       c.Nombre as NombreClase, s.Nombre as NombreRaza
                                FROM jugador j
                                LEFT JOIN clase c ON j.ID_Clase = c.ID_Clase
                                LEFT JOIN subraza s ON j.ID_Subraza = s.ID_Subraza
                                WHERE j.ID_Jugador = @JugadorId";

                using (MySqlCommand cmd = new MySqlCommand(query, conexion))
                {
                    cmd.Parameters.AddWithValue("@JugadorId", jugadorId);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            MessageBox.Show("Jugador encontrado en la base de datos", "Debug");

                            personaje = new Form10.PersonajeCompleto
                            {
                                Nombre = reader.GetString("Nombre"),
                                Clase = reader.IsDBNull(reader.GetOrdinal("NombreClase")) ? "Sin clase" : reader.GetString("NombreClase"),
                                Nivel = reader.GetInt32("ID_Nivel"),
                                Fuerza = reader.GetInt32("Fuerza"),
                                Destreza = reader.GetInt32("Destreza"),
                                Constitucion = reader.GetInt32("Constitucion"),
                                Inteligencia = reader.GetInt32("Inteligencia"),
                                Sabiduria = reader.GetInt32("Sabiduria"),
                                Carisma = reader.GetInt32("Carisma"),
                                VidaActual = reader.GetInt32("HP"),
                                VidaMax = reader.GetInt32("HP"),
                                Inventario = new System.Collections.Generic.List<Form10.Item>(),
                                EquipoActual = new Form10.Equipo()
                            };

                            MessageBox.Show($"Personaje cargado: {personaje.Nombre}", "Debug");
                        }
                        else
                        {
                            MessageBox.Show($"No se encontró ningún jugador con ID: {jugadorId}", "Advertencia");
                        }
                    }
                }
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar personaje:\n\n{ex.Message}\n\nStackTrace:\n{ex.StackTrace}", "Error Detallado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return personaje;
        }

        private void Mapa()
        {
            for (int y = 0; y < filas; y++)
            {
                for (int x = 0; x < columnas; x++)
                {
                    Panel panel = new Panel
                    {
                        Size = new Size(tileSize, tileSize),
                        Location = new Point(x * tileSize, y * tileSize),
                        BorderStyle = BorderStyle.FixedSingle,
                        BackColor = Color.DarkSlateGray
                    };

                    mapaPecio.Controls.Add(panel);

                    mapa[y, x] = new Tile
                    {
                        X = x,
                        Y = y,
                        PanelVisual = panel,
                        EsZona = false,
                        EsObstaculo = false,
                        Nombre = $"Pecio {x},{y}"
                    };
                }
            }
            SetZona(0, 10, Color.LightBlue, "Zona C1 – Cubierta Superior");
            SetZona(1, 5, Color.SaddleBrown, "Zona C2 – Castillo de Proa");
            SetZona(2, 15, Color.Sienna, "Zona C3 – Puesto de Mando");
            SetZona(3, 10, Color.MediumSeaGreen, "Zona C4 – Camarote del Capitán");
            SetZona(4, 6, Color.Orange, "Zona C5 – Cocina");
            SetZona(4, 14, Color.Goldenrod, "Zona C6 – Camarotes de la Tripulación");
            SetZona(5, 17, Color.Tan, "Zona C7 – Comedor");
            SetZona(7, 10, Color.DarkOliveGreen, "Zona C8 – Cubierta Inferior");
            SetZona(9, 10, Color.DarkSlateBlue, "Zona C9 – Bodega");
            SetZona(10, 11, Color.Indigo, "Zona C10 – Cámara del Astrolabio");
            SetEnemigo(2, 9, "Estirge");
            SetEnemigo(4, 6, "Hongo violeta");
            SetEnemigo(6, 12, "Hongo violeta");
            SetEnemigo(8, 11, "Estirge");
            SetEnemigo(10, 18, "Draco de humo");
        }

        private void SetZona(int y, int x, Color color, string nombre)
        {
            if (y < 0 || y >= filas || x < 0 || x >= columnas) return;

            var panel = mapa[y, x].PanelVisual;
            panel.BackColor = color;
            panel.Controls.Add(new Label
            {
                Text = nombre,
                Font = new Font("Segoe UI", 7),
                AutoSize = true,
                ForeColor = Color.White,
                Location = new Point(2, 2)
            });

            mapa[y, x].EsZona = true;
            mapa[y, x].Nombre = nombre;
        }

        private void SetEnemigo(int y, int x, string tipo)
        {
            if (y < 0 || y >= filas || x < 0 || x >= columnas) return;

            var panel = mapa[y, x].PanelVisual;
            panel.BackColor = Color.IndianRed;
            panel.Controls.Add(new Label
            {
                Text = tipo,
                Font = new Font("Segoe UI", 7, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(2, 2)
            });

            mapa[y, x].EsZona = true;
            mapa[y, x].Nombre = $"Enemigo: {tipo}";
        }

        private void CrearPersonaje()
        {
            jugador = new Personaje
            {
                X = 0,
                Y = 9
            };

            Panel visual = new Panel
            {
                Size = new Size(tileSize - 10, tileSize - 10),
                Location = new Point(
                    mapa[jugador.Y, jugador.X].PanelVisual.Location.X + 5,
                    mapa[jugador.Y, jugador.X].PanelVisual.Location.Y + 5
                ),
                BackColor = Color.Yellow
            };

            Label lblJugador = new Label
            {
                Text = "●",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                AutoSize = false,
                Size = visual.Size,
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.Transparent
            };
            visual.Controls.Add(lblJugador);
            jugador.Visual = visual;
            mapaPecio.Controls.Add(visual);
            jugador.Visual.BringToFront();
        }

        private void MarcarObstaculosEjemplo(int startX, int startY)
        {
            int[][] muros = new int[][]
            {
                new int[] {0,0}, new int[] {0,1}, new int[] {0,2}, new int[] {0,3}, new int[] {0,4},
                new int[] {0,5}, new int[] {0,6}, new int[] {0,7}, new int[] {0,8}, new int[] {0,9},
                new int[] {0,11}, new int[] {0,12}, new int[] {0,13}, new int[] {0,14},
                new int[] {0,15}, new int[] {0,16}, new int[] {0,17}, new int[] {0,18}, new int[] {0,19},
                new int[] {11,0}, new int[] {11,1}, new int[] {11,2}, new int[] {11,3}, new int[] {11,4},
                new int[] {11,5}, new int[] {11,6}, new int[] {11,7}, new int[] {11,8}, new int[] {11,9},
                new int[] {11,12}, new int[] {11,13}, new int[] {11,14},
                new int[] {11,15}, new int[] {11,16}, new int[] {11,17}, new int[] {11,18}, new int[] {11,19},
                new int[] {1,2}, new int[] {2,2}, new int[] {3,2}, new int[] {4,2}, new int[] {5,2}, new int[] {6,2},
                new int[] {1,8}, new int[] {2,8}, new int[] {3,8}, new int[] {4,8}, new int[] {5,8}, new int[] {6,8},
                new int[] {1,12}, new int[] {2,12}, new int[] {3,12}, new int[] {4,12}, new int[] {5,12}, new int[] {6,12},
                new int[] {1,18}, new int[] {2,18}, new int[] {3,18}, new int[] {4,18}, new int[] {5,18}, new int[] {6,18},
                new int[] {2,3}, new int[] {2,4}, new int[] {2,6}, new int[] {2,7},
                new int[] {5,3}, new int[] {5,4}, new int[] {5,6}, new int[] {5,7},
                new int[] {2,13}, new int[] {2,14}, new int[] {2,16}, new int[] {2,17},
                new int[] {5,13}, new int[] {5,14}, new int[] {5,16}, new int[] {5,17},
                new int[] {7,3}, new int[] {7,4}, new int[] {7,5},
                new int[] {7,13}, new int[] {7,14}, new int[] {7,15},
                new int[] {8,7}, new int[] {8,8}, new int[] {8,9},
                new int[] {8,12}, new int[] {8,13}, new int[] {8,14}
            };
            foreach (var pos in muros)
            {
                int y = pos[0], x = pos[1];
                if (y < 0 || y >= filas || x < 0 || x >= columnas) continue;
                if (mapa[y, x].EsZona) continue;
                if (y == startY && x == startX) continue;

                mapa[y, x].EsObstaculo = true;
                mapa[y, x].Nombre = "Muro fúngico";
                mapa[y, x].PanelVisual.BackColor = Color.Black;
            }
            var libres = new (int y, int x)[]
            {
                (9, 0), (9, 1), (9, 2), (9, 3), (9, 4), (9, 5), (9, 6), (9, 7),
                (8, 0), (8, 1), (10, 0), (10, 1)
            };

            foreach (var c in libres)
            {
                if (c.y >= 0 && c.y < filas && c.x >= 0 && c.x < columnas)
                {
                    if (mapa[c.y, c.x].EsZona) continue;

                    mapa[c.y, c.x].EsObstaculo = false;
                    mapa[c.y, c.x].PanelVisual.BackColor = Color.DimGray;
                    mapa[c.y, c.x].Nombre = $"Pecio {c.x},{c.y}";
                }
            }
        }

        private string GenerarDescripcionZona(Tile tile)
        {
            if (tile.Nombre.StartsWith("Zona C1")) return "Cofa quebrada. El mástil apunta al vacío. Nada yace aquí... por ahora.";
            if (tile.Nombre.StartsWith("Zona C2")) return "Jarcias rotas. La balista oxidada no responde. Silencio absoluto.";
            if (tile.Nombre.StartsWith("Zona C3")) return "Instrumentos náuticos olvidados. Un cofre reposa, intacto. ¿Tesoro o trampa?";
            if (tile.Nombre.StartsWith("Zona C4")) return "Puerta atrancada. El hedor a muerte es real. Zombis aguardan sin duda.";
            if (tile.Nombre.StartsWith("Zona C5")) return "Ollas vacías. Restos de festines antiguos. Nada útil... por ahora.";
            if (tile.Nombre.StartsWith("Zona C6")) return "Camastros podridos. El tablón suelto no engaña. Trampa asegurada.";
            if (tile.Nombre.StartsWith("Zona C7")) return "Platos servidos. Vajilla intacta. Pero el alma del comedor se ha ido.";
            if (tile.Nombre.StartsWith("Zona C8")) return "Escombros flotan. Un cofre sumergido espera. ¿Rescate o condena?";
            if (tile.Nombre.StartsWith("Zona C9")) return "Burbuja púrpura. El cofre del capitán respira. Talismán oculto en su vientre.";
            if (tile.Nombre.StartsWith("Zona C10")) return "Astrolabio suspendido. El aire vibra. Algo se aproxima... ¿enemigo final?";
            if (tile.Nombre.StartsWith("Enemigo: Estirge")) return "Estirge: criatura alada, sedienta de sangre. Acecha desde las sombras.";
            if (tile.Nombre.StartsWith("Enemigo: Hongo violeta")) return "Hongo violeta: emite esporas paralizantes. Su cuerpo vibra con veneno.";
            if (tile.Nombre.StartsWith("Enemigo: Draco de humo")) return "Draco de humo: elemental de gas tóxico. Su aliento es fuego y olvido.";
            return "Casilla sin eventos especiales.";
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (jugador == null) return base.ProcessCmdKey(ref msg, keyData);
            int nuevoX = jugador.X;
            int nuevoY = jugador.Y;
            bool movio = false;
            switch (keyData)
            {
                case Keys.W: nuevoY--; movio = true; break;
                case Keys.S: nuevoY++; movio = true; break;
                case Keys.A: nuevoX--; movio = true; break;
                case Keys.D: nuevoX++; movio = true; break;
            }
            if (!movio) return base.ProcessCmdKey(ref msg, keyData);
            if (nuevoX >= 0 && nuevoX < columnas && nuevoY >= 0 && nuevoY < filas)
            {
                Tile destino = mapa[nuevoY, nuevoX];
                if (!destino.EsObstaculo)
                {
                    jugador.X = nuevoX;
                    jugador.Y = nuevoY;
                    jugador.Visual.Location = new Point(
                        destino.PanelVisual.Location.X + 5,
                        destino.PanelVisual.Location.Y + 5
                    );
                    jugador.Visual.BringToFront();
                    jugador.Visual.Invalidate();
                    mapaPecio.ScrollControlIntoView(jugador.Visual);

                    ActivarZona(destino);
                }
                if (jugador.X == 0 && jugador.Y == 9)
                {
                    MessageBox.Show("Regresando al Retiro del Dragón...", "Transición", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Form5 retiro = new Form5();
                    retiro.Show();
                    retiro.MoverJugadorA(0, 0);

                    this.Close();
                    return true;
                }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void ActivarZona(Tile tile)
        {
            if (!tile.EsZona) return;
            string descripcion = GenerarDescripcionZona(tile);
            MessageBox.Show(descripcion, tile.Nombre, MessageBoxButtons.OK, MessageBoxIcon.Information);
            if (tile.Nombre.StartsWith("Zona C"))
            {
                MessageBox.Show("¡Zona despejada! Has ganado.", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (tile.Nombre.StartsWith("Enemigo:"))
            {
                MessageBox.Show($"¡Te enfrentas a un {tile.Nombre.Replace("Enemigo: ", "")}!", "¡Combate!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                MessageBox.Show("¡Enemigo derrotado! Has ganado.", "Victoria", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            tile.PanelVisual.BackColor = Color.DimGray;
            tile.PanelVisual.Controls.Clear();
            tile.Nombre = $"Pecio {tile.X},{tile.Y}";
            tile.EsZona = false;
        }

        public class Tile
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel PanelVisual { get; set; }
            public bool EsZona { get; set; }
            public bool EsObstaculo { get; set; }
            public string Nombre { get; set; }
        }

        public class Personaje
        {
            public int X { get; set; }
            public int Y { get; set; }
            public Panel Visual { get; set; }
        }
    }
}